﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadQTLData
{
    class DataHelper
    {
    }
    public class HtmlFile   //HTML文件列表类
    {
        public int ID { get; set; }
        public string FileName { get; set; }
    }

    public class HtmlData
    {
        public string TableHtml { get; set; }
        public string TableName { get; set; }
        public int HtmlID { get; set; }
        public int BelongFileID { get; set; }
        public string HtmlString { get; set; }
        public string TableX { get; set; }
        public string PMID { get; set; }
        public bool IsChoice { get; set; }
    }

    public class ExcelFile      //Excel文件名类
    {
        public int ID { get; set; }
        public string Path { get; set; }
    }

    public class ResultFile     //筛选后表格数据存数类
    {
        public int ID { get; set; }         //编号
        public string FileName { get; set; }    //表格路径
        public string[,] FormVar { get; set; }  //表格数据
        public string key { get; set; } //筛选时匹配的关键字
        public int x_key { get; set; }  //关键字所在行
        public int y_key { get; set; }
        public ResultFile clon()
        {
            return (ResultFile)MemberwiseClone();
            //this.clon();
        }
        //public int empty { get; set; }  //空单元格数量
    }
    public class FormData       //对表格提取后的数据，用于向数据库存储
    {
        public int ID { get; set; }     //编号
        public string FileName { get; set; }    //表格来源路径
        public string[,] data { get; set; }     //数据,二维数组
    }
    /*用于存储筛选所用关键字，经验证没什么用
    public class KeyWord
    {
        public int ID;
        public string key;
    }
    */
    public class FinalData      //最后整合的大表、用于存储所有表格中数据
    {
        public int ID { get; set; }
        //public string[] Head { get; set; }
        public string[] Data { get; set; }
    }
}
