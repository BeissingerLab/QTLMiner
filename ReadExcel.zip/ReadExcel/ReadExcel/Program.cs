﻿/*
 * 作者： ldy
 * 
 * 最后修改时间： 2014/5/16
 * 
 * 功能介绍：   程序主入口
 *
 *              1、无参数和有参数两种启动方式
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadQTLData
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] argv)
        {
            if (argv.Length != 0)
            {
                MessageBox.Show(argv[0], argv.Length.ToString());
                WebSupport WS = new WebSupport();
                WS.WebMain(argv);
                MessageBox.Show("over");
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new ReadQTLData());
            }
        }
    }
}
