import time
import sys

path = sys.argv[1]+"\\python\\"
i = 1
while(i<10):
	file = path+str(i)
	f = open(file,'w')
	f.close()
	i = i+1
	time.sleep(2)
