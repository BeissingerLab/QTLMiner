﻿namespace ReadQTLData
{
    partial class ReadQTLData
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.pDF2HTMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择html文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.提取表格ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.筛选表格ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.内容提取ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExcelList = new System.Windows.Forms.DataGridView();
            this.Selected1 = new System.Windows.Forms.DataGridView();
            this.Selected2 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.HtmlList = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ExcelList)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected2)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HtmlList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pDF2HTMLToolStripMenuItem,
            this.选择html文件ToolStripMenuItem,
            this.提取表格ToolStripMenuItem,
            this.选择文件ToolStripMenuItem,
            this.筛选表格ToolStripMenuItem,
            this.内容提取ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(756, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // pDF2HTMLToolStripMenuItem
            // 
            this.pDF2HTMLToolStripMenuItem.Name = "pDF2HTMLToolStripMenuItem";
            this.pDF2HTMLToolStripMenuItem.Size = new System.Drawing.Size(83, 21);
            this.pDF2HTMLToolStripMenuItem.Text = "PDF2HTML";
            this.pDF2HTMLToolStripMenuItem.Click += new System.EventHandler(this.pDF2HTMLToolStripMenuItem_Click);
            // 
            // 选择html文件ToolStripMenuItem
            // 
            this.选择html文件ToolStripMenuItem.Name = "选择html文件ToolStripMenuItem";
            this.选择html文件ToolStripMenuItem.Size = new System.Drawing.Size(93, 21);
            this.选择html文件ToolStripMenuItem.Text = "选择html文件";
            this.选择html文件ToolStripMenuItem.Click += new System.EventHandler(this.选择html文件ToolStripMenuItem_Click);
            // 
            // 提取表格ToolStripMenuItem
            // 
            this.提取表格ToolStripMenuItem.Name = "提取表格ToolStripMenuItem";
            this.提取表格ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.提取表格ToolStripMenuItem.Text = "提取表格";
            this.提取表格ToolStripMenuItem.Click += new System.EventHandler(this.提取表格ToolStripMenuItem_Click);
            // 
            // 选择文件ToolStripMenuItem
            // 
            this.选择文件ToolStripMenuItem.Name = "选择文件ToolStripMenuItem";
            this.选择文件ToolStripMenuItem.Size = new System.Drawing.Size(97, 21);
            this.选择文件ToolStripMenuItem.Text = "选择Excel文件";
            this.选择文件ToolStripMenuItem.Click += new System.EventHandler(this.选择文件ToolStripMenuItem_Click);
            // 
            // 筛选表格ToolStripMenuItem
            // 
            this.筛选表格ToolStripMenuItem.Name = "筛选表格ToolStripMenuItem";
            this.筛选表格ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.筛选表格ToolStripMenuItem.Text = "筛选表格";
            this.筛选表格ToolStripMenuItem.Click += new System.EventHandler(this.筛选表格ToolStripMenuItem_Click);
            // 
            // 内容提取ToolStripMenuItem
            // 
            this.内容提取ToolStripMenuItem.Name = "内容提取ToolStripMenuItem";
            this.内容提取ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.内容提取ToolStripMenuItem.Text = "内容提取";
            this.内容提取ToolStripMenuItem.Click += new System.EventHandler(this.内容提取ToolStripMenuItem_Click);
            // 
            // ExcelList
            // 
            this.ExcelList.AllowUserToAddRows = false;
            this.ExcelList.AllowUserToDeleteRows = false;
            this.ExcelList.AllowUserToResizeColumns = false;
            this.ExcelList.AllowUserToResizeRows = false;
            this.ExcelList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ExcelList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ExcelList.Location = new System.Drawing.Point(6, 233);
            this.ExcelList.Name = "ExcelList";
            this.ExcelList.ReadOnly = true;
            this.ExcelList.RowHeadersVisible = false;
            this.ExcelList.RowTemplate.Height = 23;
            this.ExcelList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ExcelList.Size = new System.Drawing.Size(227, 184);
            this.ExcelList.TabIndex = 0;
            this.ExcelList.TabStop = false;
            this.ExcelList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ExcelList_CellContentClick);
            // 
            // Selected1
            // 
            this.Selected1.AllowUserToAddRows = false;
            this.Selected1.AllowUserToDeleteRows = false;
            this.Selected1.AllowUserToResizeColumns = false;
            this.Selected1.AllowUserToResizeRows = false;
            this.Selected1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.Selected1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Selected1.Location = new System.Drawing.Point(6, 36);
            this.Selected1.Name = "Selected1";
            this.Selected1.ReadOnly = true;
            this.Selected1.RowHeadersVisible = false;
            this.Selected1.RowTemplate.Height = 23;
            this.Selected1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Selected1.Size = new System.Drawing.Size(233, 179);
            this.Selected1.TabIndex = 0;
            this.Selected1.TabStop = false;
            // 
            // Selected2
            // 
            this.Selected2.AllowUserToAddRows = false;
            this.Selected2.AllowUserToDeleteRows = false;
            this.Selected2.AllowUserToResizeColumns = false;
            this.Selected2.AllowUserToResizeRows = false;
            this.Selected2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Selected2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Selected2.Location = new System.Drawing.Point(6, 234);
            this.Selected2.Name = "Selected2";
            this.Selected2.ReadOnly = true;
            this.Selected2.RowHeadersVisible = false;
            this.Selected2.RowTemplate.Height = 23;
            this.Selected2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Selected2.Size = new System.Drawing.Size(233, 183);
            this.Selected2.TabIndex = 0;
            this.Selected2.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.HtmlList);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.ExcelList);
            this.groupBox1.Location = new System.Drawing.Point(12, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(239, 424);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "文件列表";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "HTML文件";
            // 
            // HtmlList
            // 
            this.HtmlList.AllowUserToAddRows = false;
            this.HtmlList.AllowUserToDeleteRows = false;
            this.HtmlList.AllowUserToResizeColumns = false;
            this.HtmlList.AllowUserToResizeRows = false;
            this.HtmlList.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.HtmlList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.HtmlList.Location = new System.Drawing.Point(6, 34);
            this.HtmlList.Name = "HtmlList";
            this.HtmlList.ReadOnly = true;
            this.HtmlList.RowHeadersVisible = false;
            this.HtmlList.RowTemplate.Height = 23;
            this.HtmlList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.HtmlList.Size = new System.Drawing.Size(227, 179);
            this.HtmlList.TabIndex = 6;
            this.HtmlList.TabStop = false;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "EXCEL文件";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.Selected1);
            this.groupBox2.Controls.Add(this.Selected2);
            this.groupBox2.Location = new System.Drawing.Point(257, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(245, 424);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "表格筛选结果";
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(163, 10);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "文件另存";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 219);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "不符合给定规则表格列表";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "符合给定规则表格列表";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(195, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 21);
            this.button1.TabIndex = 5;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.textBox2);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(508, 28);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(239, 216);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "表格提取相关配置";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(195, 100);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(31, 21);
            this.button5.TabIndex = 11;
            this.button5.Text = "...";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(6, 101);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(182, 21);
            this.textBox4.TabIndex = 10;
            this.textBox4.TabStop = false;
            this.textBox4.Text = "父母本等信息文本文件夹";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(6, 74);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(182, 21);
            this.textBox3.TabIndex = 9;
            this.textBox3.TabStop = false;
            this.textBox3.Text = "待用";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(195, 74);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(31, 21);
            this.button3.TabIndex = 8;
            this.button3.Text = "...";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(7, 47);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(181, 21);
            this.textBox2.TabIndex = 7;
            this.textBox2.TabStop = false;
            this.textBox2.Text = "补充性状信息文件所在位置";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(195, 47);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(31, 21);
            this.button2.TabIndex = 6;
            this.button2.Text = "...";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(7, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(181, 21);
            this.textBox1.TabIndex = 0;
            this.textBox1.TabStop = false;
            this.textBox1.Text = "筛选表格所需关键词文件";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(477, 6);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "自动处理";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // ReadQTLData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 464);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(750, 480);
            this.Name = "ReadQTLData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReadQTLData";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ExcelList)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Selected2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HtmlList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }



        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 选择文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 筛选表格ToolStripMenuItem;
        private System.Windows.Forms.DataGridView ExcelList;
        private System.Windows.Forms.DataGridView Selected1;
        private System.Windows.Forms.DataGridView Selected2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem 内容提取ToolStripMenuItem;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem 选择html文件ToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView HtmlList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem 提取表格ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pDF2HTMLToolStripMenuItem;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

