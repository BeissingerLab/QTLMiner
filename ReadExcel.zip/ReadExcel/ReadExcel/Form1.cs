﻿/*
 * 作者： ldy
 * 
 * 最后修改时间： 2014/5/4
 * 
 * 功能介绍：   程序界面功能部分
 *
 *              1、选择文件、根据规则筛选文件、数据过滤并存储
 *              
 *              2、增添从htm提取表格部分
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadQTLData
{
    public partial class ReadQTLData : Form
    {
        private readonly List<HtmlFile> _htmlList = new List<HtmlFile>(); //html文件
        private readonly List<ExcelFile> _excelList = new List<ExcelFile>(); //excel文件
        private readonly List<ResultFile> _cmptfile = new List<ResultFile>();   //符合要求表
        private readonly List<ResultFile> _ncmpfile = new List<ResultFile>();   //不符合要求表
        private readonly List<string> _keywordlist = new List<string>();        //关键字
        private readonly List<FormData> _datalist = new List<FormData>();       //表格数据
        private readonly List<FinalData> _finaldata = new List<FinalData>();    //最终的数据
        private string TraitPath = "";
        private string TranslatePath = "";
        private string ComplementPath = "";
        //private string ExcelPath = "";
        private string ExcelSavepath = "D:\\ExcelData\\";
        public ReadQTLData()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Clearlist(int num)//清空几个文件列表
        {
            switch (num)
            {
                case 1:
                    ExcelList.DataSource = null;
                    _excelList.Clear();

                    Selected1.DataSource = null;
                    Selected2.DataSource = null;
                    _cmptfile.Clear();
                    _ncmpfile.Clear();
                    button4.Enabled = false;
                    break;

                case 2:
                    Selected1.DataSource = null;
                    Selected2.DataSource = null;
                    _cmptfile.Clear();
                    _ncmpfile.Clear();
                    button4.Enabled = false;
                    break;
                case 3:
                    HtmlList.DataSource = null;
                    _htmlList.Clear();
                    break;
                default:
                    break;
            }
        }
        private void HtmlListDataBind()//Html文件列表内容绑定
        {
            HtmlList.DataSource = _htmlList;
            var dataGridViewColumn = HtmlList.Columns["FileName"];
            if (dataGridViewColumn != null) dataGridViewColumn.Width = 450;
            var gridViewColumn = HtmlList.Columns["ID"];
            if (gridViewColumn != null) gridViewColumn.Width = 30; //Visible = false;
            var viewColumn = HtmlList.Columns["FileName"];
            if (viewColumn != null) viewColumn.HeaderText = "文件名";
        }

        private void ExcelListDataBind()//Excel文件列表内容绑定
        {
            ExcelList.DataSource = _excelList;
            var dataGridViewColumn = ExcelList.Columns["Path"];
            if (dataGridViewColumn != null) dataGridViewColumn.Width = 450;
            var gridViewColumn = ExcelList.Columns["ID"];
            if (gridViewColumn != null) gridViewColumn.Width = 30; //Visible = false;
            var viewColumn = ExcelList.Columns["Path"];
            if (viewColumn != null) viewColumn.HeaderText = "文件名";
            //ExcelList.Rows[0].Selected = true;    //干什么用的？？
            //this.ExcelList.SelectionChanged += new System.EventHandler(this.ExcelList_SelectionChanged);
        }

        private void SelectedDataBind()//筛选后文件列表绑定
        {
            Selected1.DataSource = _cmptfile;
            Selected2.DataSource = _ncmpfile;

            var head1 = Selected1.Columns["FileName"];
            var head2 = Selected1.Columns["ID"];
            var head3 = Selected1.Columns["Key"];
            if (head1 != null)
            {
                head1.Width = 400;
                head1.HeaderText = "文件路径";
            }
            if (head2 != null) head2.Width = 30; //Visible = false;
            if (head3 != null) head3.Width = 50;

            if (null != (head1 = Selected2.Columns["FileName"]))
            {
                head1.Width = 400;
                head1.HeaderText = "文件路径";
            }
            if (null != (head2 = Selected2.Columns["ID"]))  head2.Width = 30;
            if (null != (head3 = Selected2.Columns["Key"])) head3.Width = 50;
        }

        

        private void 选择文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var selectExcelwindow = new OpenFileDialog();
            selectExcelwindow.Multiselect = true;
            selectExcelwindow.Filter = @"*.xlsx|*.xlsx";
            if (selectExcelwindow.ShowDialog() == DialogResult.OK)
            {
                Clearlist(1);    //如果选择新文件则清空现有列表
                int count = 1;
                //读取Excel文件 添加到_filelist
                foreach (var item in selectExcelwindow.FileNames)
                {
                    _excelList.Add(new ExcelFile() { Path = item, ID = count });
                    count++;
                }
                //文件路径显示到窗口
                ExcelListDataBind();

                if (ExcelList.SelectedRows.Count > 0)
                {
                    MessageBox.Show("读取成功");

                }
            }
            else
            {
                MessageBox.Show("未选择文件");
            }

        }

        private void 筛选表格ToolStripMenuItem_Click(object sender, EventArgs e)
        //根据规则筛选表格【保留含有给定关键词的表格，排除空单元格太多的表格】
        {
            Clearlist(2);
            if (_excelList.Count == 0)   //如果未选择文件，提示并返回
            {
                MessageBox.Show("无文件进行操作!");
                return;
            }

            MainFunction.readkeywork(_keywordlist, textBox1.Text);//每次筛选时重新载入keyword
            //MessageBox.Show("keyword read over!");
            if (_keywordlist.Count == 0)    //如果没有过滤词，提示并返回
            {
                MessageBox.Show("未设定过滤词!");
                return;
            }

            MainFunction.SelectTable(_cmptfile, _ncmpfile, _excelList, _keywordlist);//将所有文件按所给关键词筛选
            SelectedDataBind();
            MessageBox.Show("筛选完成!");
            button4.Enabled = true;
        }


        private void ExcelList_CellContentClick(object sender, DataGridViewCellEventArgs e)//NULL
        {

        }
        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)//NULL
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)//NULL
        {

        }
        private void textBox2_TextChanged(object sender, System.EventArgs e)
        {

        }
        private void 内容提取ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_cmptfile.Count == 0)
            {
                MessageBox.Show("无可操作数据！", "error");
                return;
            }
            /*
            if (TraitPath.Length == 0)
            {
                MessageBox.Show("未选择性状填充文件所在目录!", "error");
                return;
            }
            */
            if (TranslatePath.Length == 0)
            {
                MessageBox.Show("未选择缩写词文件所在目录!", "error");
                return;
            }
            if (ComplementPath.Length == 0)
            {
                MessageBox.Show("未选择父母本等信息文件所在目录!", "error");
                return;
            }
            _datalist.Clear();

            MainFunction.Extract(_cmptfile, _datalist, TranslatePath);     //提取筛选完表格的数据
            MessageBox.Show("提取完毕");
            _finaldata.Clear();
            MainFunction.DataMerge(_datalist, _finaldata, ComplementPath);  //对提取后数据整合
            MainFunction.OutPutData(_finaldata, "D:\\0excel\\");
            MessageBox.Show("整合完毕");
        }

        private void button4_Click(object sender, EventArgs e) 
            //将筛选后的文件转存、利于下次使用  PS调试用，正式版意义不大
        {
            var selectpath = new FolderBrowserDialog();
           // savefile.Multiselect = false;
           // savefile.Filter = @"*.xlsx|*.xlsx";
            if (selectpath.ShowDialog() == DialogResult.OK)
            {
                string path = selectpath.SelectedPath;
                MainFunction.savefile(_cmptfile, path);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        //根据给定特征词过滤表格，此按钮选择过滤关键词文本
        {
            var selecttxtwindow = new OpenFileDialog();
            selecttxtwindow.Multiselect = false;
            selecttxtwindow.Filter = @"文本文档(*.txt)|*.txt";
            if (selecttxtwindow.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = selecttxtwindow.FileNames[0];       //将文本框内容改为所选文件绝对路径
                _keywordlist.Clear();//清空keyword表
            }
            else
            {
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        //对表格性状内从进行扩充时所用文件的存储位置
        {
            var selectpath = new FolderBrowserDialog();
            selectpath.Description = "选择性状等信息所在文件夹";
            if (selectpath.ShowDialog() == DialogResult.OK)
            {
                TraitPath = selectpath.SelectedPath+"\\";
                textBox2.Text = TraitPath;
            }
            else
            {
                TraitPath = "";
                textBox2.Text = "补充性状信息文件所在位置";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var selectpath = new FolderBrowserDialog();
            selectpath.Description = "选择缩写词文本所在文件夹";
            if (selectpath.ShowDialog() == DialogResult.OK)
            {
                TranslatePath = selectpath.SelectedPath + "\\";
                textBox3.Text = TranslatePath;
            }
            else
            {
                TraitPath = "";
                textBox3.Text = "缩写词文本文件夹";
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            var selectpath = new FolderBrowserDialog();
            selectpath.Description = "选择父母本文件所在文件夹";
            if (selectpath.ShowDialog() == DialogResult.OK)
            {
                ComplementPath = selectpath.SelectedPath + "\\";
                textBox4.Text = ComplementPath;
            }
            else
            {
                TraitPath = "";
                textBox4.Text = "父母本等信息文本文件夹";
            }
        }

        private void 选择html文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var selectHtmlwindow = new OpenFileDialog();
            selectHtmlwindow.Multiselect = true;
            selectHtmlwindow.Filter = @"Web Pages(*.html;*.htm)|*.html;*.htm|*.htm|*.htm|*.html|*.html";
            if (selectHtmlwindow.ShowDialog() == DialogResult.OK)
            {
                Clearlist(3);    //如果选择新文件则清空现有列表
                int count = 1;
                //读取Html文件 添加到_htmlList
                foreach (var item in selectHtmlwindow.FileNames)
                {
                    _htmlList.Add(new HtmlFile() { FileName = item, ID = count });
                    count++;
                }
                //文件路径显示到窗口
                HtmlListDataBind();

                if (HtmlList.SelectedRows.Count > 0)
                {
                    MessageBox.Show("读取成功");
                }
            }
            else
            {
                MessageBox.Show("未选择文件");
            }
            selectHtmlwindow.Dispose();
        }

        private void 提取表格ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_htmlList.Count == 0)
            {
                MessageBox.Show("无可操作文件");
                return;
            }
            //_htmlList.Clear();
            bool bind = false;
            var selectpath = new FolderBrowserDialog();
            selectpath.Description = "Excel文件存储位置";
            if (selectpath.ShowDialog() == DialogResult.OK)
            {
                ExcelSavepath = selectpath.SelectedPath + "\\";
            }
            else
            {
                ExcelSavepath = "D:\\ExcelData\\";
            }
            selectpath.Dispose();

            DialogResult result = MessageBox.Show("是否将结果直接显示在Excel列表", "", MessageBoxButtons.YesNoCancel);
            if (result == DialogResult.Yes)
            {
                bind = true;
                Clearlist(1);
            }
            else if (result == DialogResult.No)
            {
                bind = false;
            }
            else if (result == DialogResult.Cancel)
            {
                return;
            }
            #region 提取htm文件中的table 转向excel 只需table 标签内容。
            ReadHtmlTool.ExtractTablefromFile(_htmlList, _excelList, ExcelSavepath, bind);
            if (bind)
            {
                ExcelListDataBind();
            }
            #endregion
            if (!bind || ExcelList.SelectedRows.Count > 0)
            {
                MessageBox.Show("读取完成");
            }
            else
            {
                MessageBox.Show("无表格数据");
            }
        }

        private void pDF2HTMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            List<string> pdffilelist = new List<string>();
            List<string> htmlfilelist = new List<string>();
            var selectpdffile = new OpenFileDialog();
            var savehtmfile = new SaveFileDialog();
            var savepath = new FolderBrowserDialog();
            string savehtmlpath = "D:\\0html\\";
            bool bind = false;
            selectpdffile.Multiselect = true;
            selectpdffile.Filter = "PDF Files(*.pdf)|*.pdf";
            if (selectpdffile.ShowDialog() == DialogResult.OK)
            {
                pdffilelist.Clear();
                foreach (var tmp in selectpdffile.FileNames)
                {
                    pdffilelist.Add(tmp);
                }
            }
            if (savepath.ShowDialog() == DialogResult.OK)
            {
                savehtmlpath = savepath.SelectedPath + "\\";
            }
            else
            {
                savehtmlpath = "D:\\0html\\";
            }
            if (!System.IO.Directory.Exists(ExcelSavepath))
                System.IO.Directory.CreateDirectory(ExcelSavepath);
            foreach(var tmp in pdffilelist)
            {
                
            }

        }

        
    }
}
