﻿/*
 * 作者： ldy
 * 
 * 最后修改时间： 2014/6/10
 * 
 * 功能介绍：   程序主体功能实现部分
 *
 *              1、根据规则筛选表格
 *              
 *              2、对表格内容规范化处理
 *              2.1 对没有Trait的表进行填充>5-22改写至DataJudge方法内
 *              2.2 对肚饿少的父母本信息填充（未实现）
 *              2.3 对两个Marker拆分存储
 *              2.4 对数据过滤，去除乱码、错误等问题，增添缺少部分内容
 *              2.5 将表格数据存储至19列大表
 *              2.6 将输出部分独立，可进行改进等
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel=Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;

namespace ReadQTLData
{
    class MainFunction
    {
        public static void readkeywork(List<string> _keywordlist, string filename)
        //筛选表格所用关键词读取[将结果存入_keywordlist]
        {
            _keywordlist.Clear();//清空keyword表才能再次添加
            int num = 0;        //记录文本中关键词个数，用以对每个关键词标号(没什么用。。。)

            string line = "";
            if (File.Exists(filename) == false || !Regex.IsMatch(filename, ".txt$"))
            {
                MessageBox.Show("关键词文件无效！");
                return;
            }

            StreamReader myread = new StreamReader(filename);       //开始读取文本内容
            while ((line = myread.ReadLine()) != null)
            {
                if (!Regex.IsMatch(line, @"\S"))
                {
                    continue;
                }
                num++;
                _keywordlist.Add(line);
                //MessageBox.Show(num.ToString() + " ->" + line);
            }
            myread.Close();
        }

        public static void SelectTable(List<ResultFile> cmptfile, List<ResultFile> ncmpfile,
                                    List<ExcelFile> fileList, List<string> keywordlist)
        //读取列表中excel文件并根据规则进行筛选
        {
            object missing = System.Reflection.Missing.Value;
            var myExcel = new Excel.Application();
            if (myExcel == null)
            {
                MessageBox.Show("Excel组件无法初始化！");
                return;
            }
            myExcel.DisplayAlerts = false;
            myExcel.Visible = false;
            myExcel.UserControl = true;
            //以只读的形式打开EXCEL文件

            //string[] keyword = keywordlist.ToArray();
            int cmpnum = 0, Ncmpnum = 0; //对符合规范和不符合的表格计数
            string[,] ExcelVal;        //用于存储表格内容
            foreach (var tmp in fileList)
            {
                /*打开文件*/

                var wb = myExcel.Application.Workbooks.Open(tmp.Path, missing, true, missing, missing, missing,
                    missing, missing, missing, true, missing, missing, missing, missing, missing);
                //取得第一个工作薄
                var ws = (Excel.Worksheet)wb.Worksheets.get_Item(1);

                //读取Excel内容并筛选
                int rowCount = ws.UsedRange.Rows.Count;
                int colCount = ws.UsedRange.Columns.Count;  //表格行数列数
                int empty = 0;      //表格中无内容单元格数
                ExcelVal = new string[rowCount, colCount];//对于每个表格不同大小初始化ExcelVal

                for (int i = 1; i <= rowCount; i++)
                {
                    for (int j = 1; j <= colCount; j++)
                    {
                        ExcelVal[i - 1, j - 1] = ((Excel.Range)ws.Cells[i, j]).Text.ToString();

                        if (ExcelVal[i - 1, j - 1].Length == 0)
                        {
                            empty++;
                        }
                    }
                }
                ResultFile tmpfile = new ResultFile() { FileName = tmp.Path, FormVar = ExcelVal };

                if (JudgeForm(tmpfile, keywordlist, empty))
                {
                    tmpfile.ID = ++cmpnum;
                    cmptfile.Add(tmpfile);

                }
                else
                {
                    tmpfile.ID = ++Ncmpnum;
                    ncmpfile.Add(tmpfile);
                }
                wb.Close();
            }
            myExcel.Quit();//关闭excel，不关闭会出现僵尸进程，后果严重
        }

        private static bool JudgeForm(ResultFile resultFile, List<string> keywordlist, int empty)
        // 判断表格是否符合要求[前几行含有关键词，空单元格比例小于60%]
        {
            int x = resultFile.FormVar.GetLength(0);//表格行数
            int y = resultFile.FormVar.GetLength(1);//表格列数
            int N = 5;      //前N行有关键词的表格表示有效表格
            if ((empty / (float)(x * y)) > 0.6)
            {
                // MessageBox.Show(empty.ToString() + (empty / (float)(x * y)).ToString());
                resultFile.key = "too few";
                return false;
            }
            if (y < 4 || x < 4)
            {
                resultFile.key = "wrong";
                return false;
            }
            for (int i = 0; i <= N && i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    if (resultFile.FormVar[i, j] == null || resultFile.FormVar[i, j].Length > 20 || resultFile.FormVar[i, j].Length < 2)
                    {
                        continue;
                    }
                    foreach (var key in keywordlist)
                    {
                        if (Regex.IsMatch(resultFile.FormVar[i, j], @key))
                        {
                            resultFile.key = key;
                            resultFile.x_key = i;
                            resultFile.y_key = j;
                            if (x - i < 3)
                            {
                                resultFile.key = "low-val";
                                return false;
                            }
                            return true;
                        }
                    }
                }
            }
            resultFile.key = "no mach";
            return false;
        }

        internal static void Extract(List<ResultFile> cmptfile, List<FormData> datalist, string TranslatePath)//, string TraitPath, string TranslatePath)
        //对已经筛选过的文件内容提取，规范成二维表格
        {
            StreamWriter sw = new StreamWriter("D:\\0excel\\023.txt", false, System.Text.Encoding.GetEncoding("gb2312"));
            foreach (var tmp in cmptfile)
            {
                ResultFile tmpfile = tmp.clon();
                int rowCount = tmpfile.FormVar.GetLength(0);
                int colCount = tmpfile.FormVar.GetLength(1);
                int colData = 0;
                int rowData = 0;
                bool bin = true;
                
                #region 对存在分支的列进行拆分，将其替换为子项，统计有效列PS：只拆两项的
                for (int i = 0; i < colCount; i++)  
                {
                    if (tmpfile.FormVar[tmpfile.x_key, i] == "NULL")
                    {
                        bin = true;
                        i++;
                        continue;
                    }
                    if (bin && tmpfile.FormVar[tmpfile.x_key, i].Length == 0)   //前几项空和已经查找过一次的情况排除
                    {
                        continue;
                    }
                    bin = false;

                    if (tmpfile.FormVar[tmpfile.x_key, i].Length == 0)
                    {
                        if (i + 1 < colCount && tmpfile.FormVar[tmpfile.x_key, i + 1].Length == 0)  //如果一个数据占用三个以上排除或处理
                        {
                            tmpfile.FormVar[tmpfile.x_key, i - 1] = "NULL";
                            i++;
                            while (i < colCount && tmpfile.FormVar[tmpfile.x_key, i].Length == 0)
                            {
                                i++;
                            }
                            i--;
                            //colData--;//如果存在三项则前一数据不合法，数量减一
                        }
                        else    //如果一个数据占两项，与子项合并
                        {
                            int j = 1;
                            while (tmpfile.x_key+j< colCount && tmpfile.FormVar[tmpfile.x_key + j, i - 1].Length == 0 &&
                                tmpfile.FormVar[tmpfile.x_key + j, i].Length == 0)
                            {
                                j++;
                            }


                            if (tmpfile.FormVar[tmpfile.x_key + j, i - 1].Length == 0 &&
                                tmpfile.FormVar[tmpfile.x_key + j, i].Length != 0)
                            //PS特殊情况，占用多项的数据未被合并单元格造成前一数据占两格的错误等情况
                            //  1 3     4  
                            //   2   2
                            //  12   2
                            //  12   2     此时2属于3而不属于1
                            {
                                if (i + 3 < colCount && tmpfile.FormVar[tmpfile.x_key, i + 2].Length == 0 && tmpfile.FormVar[tmpfile.x_key, i + 3].Length == 0)
                                {
                                    tmpfile.FormVar[tmpfile.x_key, i] = "NULL";
                                    tmpfile.FormVar[tmpfile.x_key, i + 1] = "";
                                    i--;
                                    continue;
                                }
                                int emp = 0;
                                for (int k = 0; k < rowCount; k++)
                                {
                                    if (tmpfile.FormVar[k, i].Length == 0)
                                    {
                                        emp++;
                                    }
                                }
                                if (emp / (float)colCount < 0.5)
                                {
                                    tmpfile.FormVar[tmpfile.x_key, i] = tmpfile.FormVar[tmpfile.x_key + j, i];
                                }
                                else
                                {
                                    tmpfile.FormVar[tmpfile.x_key, i] = "NULL";
                                }
                                continue;
                            }
                            else if (tmpfile.FormVar[tmpfile.x_key + j, i - 1].Length != 0 &&
                                tmpfile.FormVar[tmpfile.x_key + j, i].Length == 0)
                            {
                                tmpfile.FormVar[tmpfile.x_key, i] = "NULL";
                                continue;
                            }
                            else
                            {
                                tmpfile.FormVar[tmpfile.x_key, i] = tmpfile.FormVar[tmpfile.x_key, i - 1];
                                tmpfile.FormVar[tmpfile.x_key, i - 1] += "-" + tmpfile.FormVar[tmpfile.x_key + j, i - 1];
                                tmpfile.FormVar[tmpfile.x_key, i] += "-" + tmpfile.FormVar[tmpfile.x_key + j, i];
                                tmpfile.FormVar[tmpfile.x_key + j, i - 1] = "";
                                tmpfile.FormVar[tmpfile.x_key + j, i] = "";
                               // i++;
                                //colData++;
                            }
                        }
                    }
                    else
                    {
                        //colData++;
                    }
                }
                #endregion
                //bool noTrait = true;    //标记表格是否为无Trait
                //bool noParent = true;
                for (int i = 0; i < colCount; i++)
                {
                    if (tmpfile.FormVar[tmpfile.x_key, i] != "NULL" && tmpfile.FormVar[tmpfile.x_key, i].Length != 0)
                    {
                        if (Regex.IsMatch(tmpfile.FormVar[tmpfile.x_key, i], @"Trait"))//检测是否含有Trait列
                        {
                            //如果找到Trait列，标记并用上方数据填充下方数据
                            //noTrait = false;
                            bool noTrait = false;
                            int j = tmpfile.x_key + 1;
                            while (tmpfile.FormVar[j, i] == null || tmpfile.FormVar[j, i].Length == 0)
                            {
                                j++;
                                if (j == rowCount)
                                {
                                    noTrait = true;
                                    break;
                                }
                            }
                            if (!noTrait)
                            {
                                //tmpfile.FormVar[tmpfile.x_key, i] = "";
                                string trait = tmpfile.FormVar[j, i];
                                for (; j < rowCount; j++)
                                {
                                    if (tmpfile.FormVar[j, i] == null || tmpfile.FormVar[j, i].Length == 0)
                                    {
                                        tmpfile.FormVar[j, i] = trait;
                                    }
                                    else
                                    {
                                        trait = tmpfile.FormVar[j, i];
                                    }
                                }
                            }
                        }

                        colData++;
                    }
                }
                if (colData < 3)    //有效列数太少视为排除
                {
                    continue;
                }

                bool add = false;   //是否添加未知列项目
                string[] other = new string[rowCount];  //一个临时数组用于存储关键词所在列含有的其他列信息
                rowData = 1;
                for (int i = tmpfile.x_key + 1; i < rowCount; i++)  //根据关键词所在列元素数决定有效行
                {
                    int emp = 0;
                    for (int j = 0; j < colCount; j++)
                    {
                        if (tmpfile.FormVar[i, j].Length == 0)
                        {
                            emp++;
                        }
                    }
                    if (tmpfile.FormVar[i, tmpfile.y_key].Length != 0 )
                    {
                        if (i > 1 && colCount - emp <= 4 && colCount != emp) //特殊处理，若关键词所在列掺杂其他类元素则提出
                        {
                            other[i] = tmpfile.FormVar[i, tmpfile.y_key].Replace("-OTHER", "");
                            if (!Regex.IsMatch(tmpfile.FormVar[i, tmpfile.y_key], "OTHER"))
                            {
                                tmpfile.FormVar[i, tmpfile.y_key] += "-OTHER";
                            }
                            if (!add)
                            {
                                colData++;
                                add = true;
                            }
                            continue;
                        }
                        rowData++;
                    }
                    else if (colCount - emp >= emp)
                    {
                        if (tmpfile.FormVar[i - 1, tmpfile.y_key] != "")
                        {
                            tmpfile.FormVar[i, tmpfile.y_key] = tmpfile.FormVar[i - 1, tmpfile.y_key];
                        }
                        else
                        {
                            tmpfile.FormVar[i, tmpfile.y_key] = "EMPTY";
                        }
                        rowData++;

                    }
                }
                //源数据处理完毕、进行转存

                string[,] tmpform = new string[rowData, colData];
                int row = 0, col = 0;
                if (add)
                {
                    getname(other);
                    tmpform[0, colData - 1] = other[0];
                    int othernum = 1;
                    while (othernum < rowData)
                    {
                        tmpform[othernum++, colData - 1] = "";
                    }
                }

                for (int i = tmpfile.x_key; i < rowCount; i++)
                {
                    if (tmpfile.FormVar[i, tmpfile.y_key].Length == 0 || tmpfile.FormVar[i, tmpfile.y_key] == "EMPTY")
                    {
                        //tmpform[i, tmpfile.y_key] = "";
                        continue;
                    }
                    if (Regex.IsMatch(tmpfile.FormVar[i, tmpfile.y_key], "OTHER"))
                    {
                        int addnum = row;
                        while (addnum < rowData)
                        {
                            tmpform[addnum, colData - 1] = other[i];
                            addnum++;
                        }
                        continue;
                    }
                    for (int j = 0; j < colCount; j++)
                    {
                        if (tmpfile.FormVar[tmpfile.x_key, j].Length == 0 || tmpfile.FormVar[tmpfile.x_key, j] == "NULL")
                        {
                            continue;
                        }
                        tmpform[row, col++] = tmpfile.FormVar[i, j];
                    }
                    row++;
                    col = 0;
                }
                FormData tmpdata = new FormData() { ID = tmpfile.ID, data = tmpform, FileName = Path.GetFileNameWithoutExtension(tmp.FileName) };

                replace(tmpdata, TranslatePath, rowData, colData);   //将表格中缩写替换为全称

                datalist.Add(tmpdata);
                #region debug 用
                string seesee = "";
                sw.Write(tmp.ID.ToString()+" "+ Path.GetFileName(tmp.FileName) + "\n");

                for (int p = 0; p < rowData; p++)
                {
                    for (int q = 0; q < colData; q++)
                    {
                        seesee += tmpform[p, q] + '\t';
                    }
                    seesee += '\n';
                }
                sw.Write(seesee);
                #endregion
                // MessageBox.Show(seesee, tmpdata.ID.ToString());
               // MessageBox.Show(tmpdata.ID.ToString());
            }
            sw.Close();
        }

        private static void replace(FormData tmpdata, string TranslatePath, int row, int col)
            //将表格中缩写词替换为全名
        {
            Regex regex = new Regex(@"table([0-9]+)");    //正则表达式用于修改文件名
           // string[] s = regex.Replace(data.data[i, j], "@").Split('@');
            string filename = TranslatePath + tmpdata.FileName + ".txt";
            filename = regex.Replace(filename, "");
            if (File.Exists(filename))
            {
                List<string[]> word = new List<string[]>();
                string line = "";
                StreamReader myread = new StreamReader(filename);       //开始读取文本内容
                while ((line = myread.ReadLine()) != null)
                {
                    if (!Regex.IsMatch(line, @"\S"))
                    {
                        continue;
                    }
                    line = Regex.Replace(line,@"([\(|\)|\[|\]|\?])",@"\$1");
                    //line = line.Replace(@"(", @"\(");
                    word.Add(line.Split(':'));
                }
                myread.Close();
                for (int i = 1; i < row; i++)
                {
                    for (int j = 0; j < col; j++)
                    {
                        foreach (var key in word)
                        {
                            if (tmpdata.data[i, j] != null && Regex.IsMatch(tmpdata.data[i, j], key[0]) && tmpdata.data[i,j].Length - key[0].Length <= 4)    //如果发现缩写词（初步设定后边跟空格的才是缩写词）进行替换
                            {
                                tmpdata.data[i, j] = tmpdata.data[i, j].Replace( key[0],key[1]);
                                break;
                            }
                        }
                    }
                }
            }
        }

        internal static void DataMerge(List<FormData> datalist, List<FinalData> finaldata, string ComplementPath)
        //将表格数据存储到19列的大表
        {

            string[] headstr = { "File", "Trait", "QTL", "Marker-1", "Marker-2", "LG", "Pvalue", "LoD", "R", "PVE/Variation", "ADD", "Ref", "Location", "Year", "Parents", "Method", "Position", "Gene", "Type/size" };
            finaldata.Add(new FinalData() { ID = 0, Data = headstr });
            int num = 0;    //标记数据条数
            
            string[][] checkword = new string[19][];    //重点！！用于找到标题位置的正则表达式
            checkword[0] = null;
            checkword[1] = new string[] { @"(T|t)rait" }; //Trait
            checkword[2] = new string[] { "osition", @"(pos|POS|Pos)" };   //Position
            checkword[3] = new string[] { "nterval", @"(M|m)a(r|)ker", @"Loc(i|us)" };   //Marker
            checkword[4] = null;//new string[] { "nterval", @"(M|m)arker", "maker" };   //Marker
            checkword[5] = new string[] { @"L(.|)G", "Chr", "Linkage" };             //LG
            checkword[6] = new string[] { @"(P|p).{0,}(V|v)alue", @"^P$" };      //P-value
            checkword[7] = new string[] { "LOD" };    //LoD
            checkword[8] = new string[] { @"(R|r).{0,}(V|v)alue", @"^R$", @"R2" };      //R?没找到,按P-value规则
            checkword[9] = new string[] { "PVE", "QTL.?(V|v)ar", "Var" };     //PVE和Variation关键词少
            checkword[10] = new string[] { "Add" }; //ADD
            checkword[11] = new string[] { "Ref" }; //Ref
            checkword[12] = new string[] { "Loca", @"(E|e)nv" };   //Location
            checkword[13] = new string[] { "Year" }; //Year
            checkword[14] = new string[] { "Parent", "Populat", "source" };    //Parents
            checkword[15] = new string[] { "Method", "method" };   //Method\
            checkword[16] = new string[] { "QTL" };      //QTL
            checkword[17] = new string[] { @"Gene$" };   //Gene
            checkword[18] = new string[] { @"(t|T)ype" };   //Type/size

            foreach (var data in datalist)
            {
                int rowData = data.data.GetLength(0);   //数据行
                int colData = data.data.GetLength(1);   //数据列
                int[] pos = new int[colData];           //存储表头标示符对应大表的位置
                int colFinalData = 19;
                string[,] tmpstr = new string[rowData, colFinalData]; //将数据对应大表存储的临时存储位置
                int marker = -1;
                
                for (int i = 0; i < colData; i++)
                {
                    if (data.data[0, i] == null)
                    {
                        pos[i] = 0;
                        continue;
                    }
                    //对表头标签处理，对应到大表相应位置
                    bool find = false;
                    string[] key;
                    for(int j=1;j<checkword.Length;j++)// key in checkword)
                    {
                        key = checkword[j];
                        if (key == null)
                        {
                            continue;
                        }
                        foreach (var word in key)
                        {
                            Regex regex = new Regex(word);
                            if (regex.IsMatch(data.data[0, i]))
                            {
                                if (j == 3)
                                {

                                    if (marker < 0)
                                    {
                                        pos[i] = -3;
                                        marker = i;
                                    }
                                    else if (pos[marker] == -3)
                                    {
                                        pos[marker] = 3;
                                        pos[i] = 4;
                                    }
                                }
                                else if (j == 2)    //后判断的QTL、位置修正到原来位置
                                {
                                    pos[i] = 16;
                                }
                                else if (j == 16)
                                {
                                    pos[i] = 2;
                                }
                                else
                                {
                                    pos[i] = j;
                                }
                                find = true;
                                break;
                            }
                        }
                        if (find)
                        {
                            break;
                        }
                    }
                }
                for (int j = 0; j < colData; j++)   //对数据读出
                {

                    if (pos[j] == 0)
                    {
                        //如果未匹配到，如何处理待定
                        continue;
                    }
                    else if (pos[j] < 0)
                    {
                        Regex regex = new Regex(@"[a-zA-Z]{2,}.?[0-9]+(a-zA-Z|)");    //正则表达式用于相对模糊匹配marker项
                        for (int i = 1; i < rowData; i++)
                        {
                            if (data.data[i, j] == null || data.data[i, j].Length == 0)
                            {
                                continue;
                            }
                            /*
                            string[] s = regex.Replace(data.data[i, j], "@").Split('@');
                            //拆分data.data[i, j]中两项存入s1,s2,可能用正则匹配

                            tmpstr[i, -pos[j]] = s[0];
                            if (s.Length > 1)
                                tmpstr[i, -pos[j] + 1] = s[1];
                             */
                            MatchCollection mc;
                            mc = regex.Matches(data.data[i, j]);
                            if (mc.Count < 1)
                            {
                                tmpstr[i, -pos[j]] = data.data[i,j];
                            }
                            else if (mc.Count > 1)
                            {
                                tmpstr[i, -pos[j]] = mc[0].Value;
                                tmpstr[i, -pos[j] + 1] = mc[1].Value;
                                tmpstr[i, -pos[j] + 1] = tmpstr[i, -pos[j] + 1].Replace(@"-", "");
                            }
                            else
                            {
                                tmpstr[i, -pos[j]] = mc[0].Value;
                            }
                        }
                    }
                    else if(pos[j] == 3 || pos[j] == 4)
                    {
                        Regex regex = new Regex(@"[a-zA-Z]{2,}.?[0-9]+(a-zA-Z|)");    //正则表达式用于相对模糊匹配marker项
                        for (int i = 1; i < rowData; i++)
                        {
                            if (data.data[i, j] == null || data.data[i, j].Length == 0)
                            {
                                continue;
                            }
                            MatchCollection mc;
                            mc = regex.Matches(data.data[i, j]);
                            if (mc.Count < 1)
                            {
                                tmpstr[i, pos[j]] = data.data[i, j];
                            }
                            else if (mc.Count > 1)
                            {
                                tmpstr[i, pos[j]] = mc[0].Value + mc[1].Value;
                                //tmpstr[i, pos[j] + 1] = mc[1].Value;
                                //tmpstr[i, pos[j] + 1] = tmpstr[i, -pos[j] + 1].Replace(@"-", "");
                            }
                            else
                            {
                                tmpstr[i, pos[j]] = mc[0].Value;
                            }
                        }
                    }
                    else
                    {
                        for (int i = 1; i < rowData; i++)
                        {
                            if (tmpstr[i, pos[j]] == null || tmpstr[i, pos[j]].Length == 0)
                            {
                                tmpstr[i, pos[j]] = data.data[i, j];
                            }
                            else if(data.data[i,j] != null && data.data[i,j].Length != 0)
                            {
                                tmpstr[i, pos[j]] += "*" + data.data[i, j];
                            }
                        }
                    }
                }

                for (int i = 1; i < rowData; i++)
                {
                    if (tmpstr[i, 3] == null || !Regex.IsMatch(tmpstr[i, 3], @"[a-zA-Z]{2,}.?[0-9]+(a-zA-Z|)"))//无marker和不合理marker数据排除
                    {
                        continue;
                    }
                    string[] ss = new string[colFinalData];
                    ss[0] = data.FileName;
                    num++;
                    for (int j = 1; j < colFinalData; j++)
                    {
                        if (tmpstr[i, j] == null)
                        {
                            ss[j] = "";
                        }
                        else
                        {
                            ss[j] = tmpstr[i, j];
                        }
                    }
                    //对数据每一项做排错处理
                    if (DataJudge(ss, colFinalData, ComplementPath))
                    {
                        FinalData tmpdata = new FinalData() { ID = num, Data = ss };
                        finaldata.Add(tmpdata);
                    }
                }
            }

            //MessageBox.Show(headstr.Length.ToString()+finaldata[0].Data[3]+"  "+headstr[1]);
            //finaldata.Add(new FinalData { ID = 0, Data = new string[14] = { );
        }

        private static bool DataJudge(string[] Data, int col, string ComplementPath)
        //对数据最后进行排错、补充、纠错等处理
        {
            for (int i = 0; i < col; i++)
            {
                if (Data[i] == null || Regex.IsMatch(Data[i], @"(>|=|[\u4e00-\u9fa5])"))    //空内容、乱码内容、htm标签型数据清空
                {
                    Data[i] = "";
                }
            }
            string tablename = ComplementPath + Data[0]; //带表格号文件名用于补充信息所用文件
            string Articlename = Regex.Replace(tablename, @"table\d+", "");   //文章文件名用于补充不区分表格的信息文件夹
            string textname = Articlename.Replace("Complement", "text"); //PDF转为文本文件所在位置

            if (!Regex.IsMatch(Data[1], @"SW") && Regex.IsMatch(Data[1], @"^\d+.*"))
            {
                Data[1] = "";
            }
            if (Regex.IsMatch(Data[3], @"[^\d\w\-_ ]"))     //消除乱码
            {
                Data[3] = Regex.Replace(Data[3], @"[^\d\w_\- ]+", " ");
            }
            if (!Regex.IsMatch(Data[4], @"[a-zA-Z]+.?[0-9]+(a-zA-Z|)")) //第二项marker如果不符合marker模糊模式则清空
            {
                Data[4] = "";
            }
            if (Regex.IsMatch(Data[4], @"[^\d\w\-_ ]"))      //消除乱码
            {
                Data[4] = Regex.Replace(Data[4], @"[^\d\w_\- ]+", " ");
            }

            if (Regex.IsMatch(Data[6], @"[^\d.+-]"))    //对Pvalue项数据进行修正、去掉不符合数字规范字符
            {
                Data[6] = Regex.Replace(Data[6], @"[^\d.+-]", "");
            }
            if (Regex.IsMatch(Data[7], @"[^\d.+-]"))    //对LoD项数据进行修正、去掉不符合数字规范字符
            {
                Data[7] = Regex.Replace(Data[7], @"[^\d.+-]", "");
            }
            if (Regex.IsMatch(Data[8], @"[^\d.+-]"))    //对R项数据进行修正、去掉不符合数字规范字符
            {
                Data[8] = Regex.Replace(Data[8], @"[^\d.+-]", "");
            }
            if (Regex.IsMatch(Data[9], @"[^\d.+-]"))    //对PVE/Variation项数据进行修正、去掉不符合数字规范字符
            {
                Data[9] = Regex.Replace(Data[9], @"[^\d.+-]", "");
            }
            if (Regex.IsMatch(Data[10], @"[^\d.+-]"))   //对ADD项数据进行修正、去掉不符合数字规范字符
            {
                Data[10] = Regex.Replace(Data[10], @"[^\d.+-]", "");
            }
            if (Regex.IsMatch(Data[16], @"[^\d.+-]"))   //对Position项数据进行修正、去掉不符合数字规范字符
            {
                Data[16] = Regex.Replace(Data[16], @"[^\d.+-]", "");
            }

            if (File.Exists(tablename + ".trait"))  //对Trait项进行填充、表格内有则拼接、无则填充、乱码纠错；time:5-22
            {
                string trait = "";
                StreamReader myread = new StreamReader(tablename + ".trait");       //开始读取文本内容
                if ((trait = myread.ReadLine()) != null)
                {
                    if (Data[1] == "" )
                    {
                        Data[1] = trait;
                    }
                    else
                    {
                        Data[1] = trait + "-" + Data[1];
                    }
                }

                myread.Close();
            }
            if (Data[14].Length == 0 && File.Exists(tablename + ".parent"))    //如果父母本列为空且存在补充文件
            {
                string parents = "";
                StreamReader myread = new StreamReader(tablename + ".parent");       //开始读取文本内容
                if ((parents = myread.ReadLine()) != null)
                {
                    if (parents.Length != 0)
                    {
                        Data[14] = parents;
                    }
                }
                myread.Close();
            }
            if (Data[18].Length == 0 && File.Exists(tablename + ".ril"))    //如果种群大小列为空且存在补充文件
            {
                string RIL = "";
                StreamReader myread = new StreamReader(tablename + ".ril");       //开始读取文本内容
                if ((RIL = myread.ReadLine()) != null)
                {
                    if (RIL.Length != 0)
                    {
                        Data[18] = RIL;
                    }
                }
                myread.Close();
            }
            if (Data[11].Length == 0 || !Regex.IsMatch(Data[11], @"\(\d+\)"))    //如果Ref列为空或者无数字项且存在补充文件
            {
                if (File.Exists(Articlename + ".ref"))
                {
                    string Ref = "";
                    StreamReader myread = new StreamReader(Articlename + ".ref");       //开始读取文本内容
                    if ((Ref = myread.ReadLine()) != null)
                    {
                        if (Ref.Length != 0)
                        {
                            Data[11] = Ref;
                        }
                    }
                    myread.Close();
                }
            }
            else if (File.Exists(textname + ".txt")) //如果已有内容则在文中查找指向内容进行替换(表格中内容为作者名+年份)
            {
                StreamReader myread = new StreamReader(textname + ".txt");
                string text = "";
                string[] Ref = Data[11].Split(' ');
                string author = Ref.First();                                    //获取作者名，表格中作者名均为第一词
                string time = Regex.Replace(Data[11], @"(.*\()(.*)(\).*)", "$2"); //括号内为年份
                while ((text = myread.ReadLine()) != null)
                {
                    if (Regex.IsMatch(text, @"^Referen[a-zA-Z]+$", RegexOptions.IgnoreCase))
                    {
                        break;
                    }
                }
                while ((text = myread.ReadLine()) != null)
                {
                    if (Regex.IsMatch(text, author) && Regex.IsMatch(text, time))
                    {
                        Data[11] = text;
                        break;
                    }
                }
            }
            #region 对marker项进行纠错等处理、此项很重要、为保证效果放置DataJudge最下端
            if (Regex.IsMatch(Data[3], @"^(\w*at)([^0-9]*)(\d+)([^0-9].*)?"))
            {
                Data[3] = Regex.Replace(Data[3], @"^(\w*at)([^0-9]*)(\d+)([^0-9].*)?", @"Satt$3");
                if (true) ;
            }
            if (Regex.IsMatch(Data[4], @"^(\w*at)([^0-9]*)(\d+)([^0-9].*)?"))
            {
                Data[4] = Regex.Replace(Data[4], @"^(\w*at)([^0-9]*)(\d+)([^0-9].*)?", @"Satt$3",RegexOptions.RightToLeft);
                if (true) ;
            }
            if (!Regex.IsMatch(Data[3], "Satt") && Regex.IsMatch(Data[4], "Satt")) //如果第一项marker不符合规范而第二项符合规范则将后者填充至前者、保证数据统一性
            {
                Data[3] = Data[4];
                Data[4] = "";
            }
            if (!Regex.IsMatch(Data[3], "Satt") && (Data[5].Length == 0 || Data[16].Length == 0))   //如果marker项为自定义名称且无LG和position则数据无意义
            {
                Data[3] = Data[4] = "";
            }
            #endregion

            for (int i = 0; i < col; i++) //数据检错、填充后最后纠错
            {

                Data[i] = Regex.Replace(Data[i].Replace("?", "fl").Replace(@"ﬂ", "fl").Replace("ﬁ", "fi"), @"([\u4e00-\u9fa5])", "");    //乱码内容清空、'ﬂ'字符为'fl'转换错误导致
            }
            if ((Data[3].Length == 0 && Data[4].Length == 0) || Data[1].Length == 0 || Data[11].Length == 0)//marker、trait、ref为数据核心项、任意一项缺失则数据参考价值不大
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        private static void getname(string[] other) //如果存在其他列元素，为这个找到所属
        {
            other[0] = "other";
        }

        internal static void savefile(List<ResultFile> _cmptfile, string SavePath)  //将筛选后列表中文件转存用
        {
            foreach (var cmptfile in _cmptfile)
            {
                File.Copy(cmptfile.FileName, SavePath + "\\"+Path.GetFileName(cmptfile.FileName), true);
            }
        }

        internal static void OutPutData(List<FinalData> _finaldata, string WORKPATH)
            //对最后数据输出、可做多种形式、暂时为txt
        {
            string outputfile = WORKPATH + "FinalData.txt";
            System.IO.StreamWriter sw = new System.IO.StreamWriter(outputfile, false, System.Text.Encoding.Default);
            string ss = "";
            foreach (var data in _finaldata)
            {
                for (int i = 0; i < 19; i++)
                {
                    ss += data.Data[i] + '\t';
                }
                ss += '\n';
                sw.Write(ss);
                ss = "";
            }
            sw.Close();
        }
    }

}
