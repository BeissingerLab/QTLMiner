﻿/*
 * 作者： ldy
 * 
 * 最后修改时间： 2014/6/10
 * 
 * 功能介绍：   Web支持模块
 *
 *              1、此部分作为网站后台处理部分，对PDF文件中表格数据进行提取、整合；对文本、表头等处理提取信息，整合所有模块。
 * 
 *              2、后台处理数据，无界面
 *              
 *              3、整合填充数据
 *              
 *              4、采用多线程处理数据与表格两部分提高效率（未实现）
 *              
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Threading;
using System.Diagnostics;
//using IronPython.Hosting;
//using Microsoft.Scripting.Hosting;

namespace ReadQTLData
{
    public class WebSupport
    {
        private readonly List<HtmlFile> _htmlList = new List<HtmlFile>(); //html文件
        private readonly List<ExcelFile> _excelList = new List<ExcelFile>(); //excel文件
        private readonly List<ResultFile> _cmptfile = new List<ResultFile>();   //符合要求表
        private readonly List<ResultFile> _ncmpfile = new List<ResultFile>();   //不符合要求表
        private readonly List<string> _keywordlist = new List<string>();        //关键字列表
        private readonly List<FormData> _datalist = new List<FormData>();       //表格数据
        private readonly List<FinalData> _finaldata = new List<FinalData>();    //最终的数据
        private readonly List<string> _pdffilelist = new List<string>();    //pdf文件列表
        
        #region 后台部分固定每种文件位置、统一不同模块数据接口
        private string WORKPATH = "";   //不同模块统一工作路径，也是唯一参数
        private string LocalPath = "";  //程序自身所在路径
        private string HtmPath = ""; //html文件位置
        private string AbbreviationPath = "";   //缩写词所在文件夹
        private string Text = "";       //文章文本（去除表中内容）
        private string Tabletext = "";  //表格中内容
        private string Table = "";      //表头内容
        private string Table_deal = "";    //句子分割后存储位置
        //private string HtmPath = "";    //
        //private string TraitPath = "";  //性状信息所在文件夹
        private string ComplementPath = "";     //其他补充信息所在位置
        private string ExcelSavePath = "";   //Excel存储位置

        private string KeywordFile = ".\\marker.txt";    //关键词文件
        #endregion

        //FILEPATH = "";
        public void WebMain(string[] argv)
            //主程序部分，后台处理数据（提取到Htm后采用多线程处理，未实现）
        {
            //System.Windows.Forms.MessageBox.Show(ExcelSavePath);
            WORKPATH = argv[0] + "\\";
            LocalPath = System.Windows.Forms.Application.StartupPath + "\\";
            //TraitPath = WORKPATH + "\\Trait\\";
            KeywordFile = LocalPath + "marker.txt";
            ComplementPath = WORKPATH + "Complement\\";
            AbbreviationPath = WORKPATH + "Abbreviation\\";
            ExcelSavePath = WORKPATH + "Excel\\";
            HtmPath = WORKPATH + "htm\\";
            Table = WORKPATH + "table\\";
            Table_deal = WORKPATH + "table_deal\\";
            Text = WORKPATH + "text\\";
            Tabletext = WORKPATH + "tabletext\\";

            if (!Directory.Exists(HtmPath))
            {
                System.Windows.Forms.MessageBox.Show("No htm Path !");
                return;
            }
            if (!File.Exists(KeywordFile))
            {
                System.Windows.Forms.MessageBox.Show("No Marker File !");
                return;
            }
            //检查文件夹是否存在、不存在则建立
            if (!Directory.Exists(ExcelSavePath))
                Directory.CreateDirectory(ExcelSavePath);
            if (!Directory.Exists(Table))
                Directory.CreateDirectory(Table);
            if (!Directory.Exists(Table_deal))
                Directory.CreateDirectory(Table_deal);
            if (!Directory.Exists(ComplementPath))
                Directory.CreateDirectory(ComplementPath);
            if (!Directory.Exists(AbbreviationPath))
                Directory.CreateDirectory(AbbreviationPath);
            if (!Directory.Exists(Text))
                Directory.CreateDirectory(Text);
            if (!Directory.Exists(Tabletext))
                Directory.CreateDirectory(Tabletext);

            #region 读取并转换PDF，暂时无转换部分，用Htm代替
            DirectoryInfo dir = new DirectoryInfo(@HtmPath);
            int num = 0;
            foreach (var file in dir.GetFiles("*.htm"))
            {
                num++;
                _htmlList.Add(new HtmlFile { FileName = file.FullName, ID = num });
            }
            #endregion
            
            Thread[] Threads = new Thread[2];
            Threads[0] = new Thread(new ThreadStart(ExcelData));
            Threads[0].Name = "Thread1";
            Threads[0].SetApartmentState(ApartmentState.STA);   //设置此线程为一个单线程单元，否则粘贴板使用处出错！！！
            
            //设置第二个线程
            Threads[1] = new Thread(new ThreadStart(TextData));
            Threads[1].Name = "Thread2";
            //启动两线程
            Threads[0].Start();
            Threads[1].Start();
            //等待结束
            Threads[0].Join();
            Threads[1].Join();

            //ExcelData();    //表格读取、筛选部分
            //TextData();     //其他文本抽取信息等处理部分
            //此部分应使用多线程

            MainFunction.Extract(_cmptfile, _datalist, AbbreviationPath);
            MainFunction.DataMerge(_datalist, _finaldata, ComplementPath);
            MainFunction.OutPutData(_finaldata, WORKPATH);
            return;
        }

        private void TextData()
        //对文本缩写和表头、表尾等进行相关处理
        {
            #region 测试多线程与python调用
            /*
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = "python.exe";
            psi.WorkingDirectory = "D:\\Study\\soybean\\QTL表格处理\\ReadExcel\\ReadExcel\\bin\\Debug\\";
            psi.Arguments = "creatfile.py .\\";
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            psi.UseShellExecute = false;
            //psi.RedirectStandardOutput = true;
            psi.CreateNoWindow = true;
            Process process = Process.Start(psi);
            process.WaitForExit();
            */
            #endregion
            ExecuteProcess("perl.exe", "script\\HtmltoText.pl " + WORKPATH, LocalPath);
            ExecuteProcess("perl.exe", "script\\TableHead.pl " + WORKPATH, LocalPath);
            ExecuteProcess("perl.exe", "script\\FindRef.pl " + WORKPATH, LocalPath);
            ExecuteProcess("python.exe", "script\\GetAbbreviation.py " + WORKPATH, LocalPath);
            ExecuteProcess("python.exe", "Project\\Project.py " + WORKPATH, LocalPath); //此脚本从表头获取trait和parent
        }

        private void ExcelData()
        //对表格进行提取、筛选工作
        {

            ReadHtmlTool.ExtractTablefromFile(_htmlList, _excelList, ExcelSavePath, true);
            MainFunction.readkeywork(_keywordlist, KeywordFile);
            MainFunction.SelectTable(_cmptfile, _ncmpfile, _excelList, _keywordlist);//将所有文件按所给关键词筛选
        }
        private void ExecuteProcess(string fileName, string argvs, string workingDirectory)
        //执行外部程序函数，参数：filename所执行程序，含全路径或已添加环境变量；argvs：参数；workingDirectory：工作路径
        {
            ProcessStartInfo psi = new ProcessStartInfo();
            psi.FileName = fileName;
            psi.WorkingDirectory = workingDirectory;
            psi.Arguments = argvs;
            psi.WindowStyle = ProcessWindowStyle.Hidden;
            psi.UseShellExecute = false;
            //psi.RedirectStandardOutput = true;
            psi.CreateNoWindow = true;
            Process process = Process.Start(psi);
            process.WaitForExit();  //等待外部程序结束、子线程内各处理部分按顺序执行**必须加
        }
    }
}
