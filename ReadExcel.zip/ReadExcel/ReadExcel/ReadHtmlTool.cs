﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using Excel = Microsoft.Office.Interop.Excel;

namespace ReadQTLData
{
    class ReadHtmlTool
    {
        private static readonly object MObjOpt = System.Reflection.Missing.Value;

        // Paths used by the sample code for accessing and storing data.

        public static void ExtractTablefromFile(List<HtmlFile> htmlList, List<ExcelFile> excelList, string ExcelSavepath, bool bind)
        {
            if (!Directory.Exists(ExcelSavepath))
                Directory.CreateDirectory(ExcelSavepath);
            int tempcount = 0;
            int excelnum = 0;
            var document = new HtmlAgilityPack.HtmlDocument();
            foreach (var item in htmlList)
            {

                var fileName = item.FileName;
                document.Load(fileName);
                string head = document.DocumentNode.SelectSingleNode("//head").InnerHtml;

                var tableNodes = document.DocumentNode.SelectNodes("//table");
                //var tablehtmllist = new List<string>();
                int TableCount = 1;
                if (tableNodes == null)
                {
                    continue;
                }
                foreach (var itemTable in tableNodes)
                {
                    var flag = itemTable.SelectNodes("tr");
                    if (flag != null)
                    {
                        if (flag.Count > 3)
                        {
                            string s = " <table>" + itemTable.InnerHtml + "</table>";//此内容即为table
                            string html = "<html><head>" + head + "</head><body>" + s + "</body></html>";
                            //查看s，html
                            // System.Windows.Forms.MessageBox.Show(itemTable.InnerHtml);

                            var tempHtmlData = new HtmlData()
                            {
                                BelongFileID = item.ID,
                                HtmlString = html,
                                HtmlID = TableCount,
                                TableHtml = s,
                                PMID = fileName,
                                TableX = "Table" + TableCount.ToString(),
                                TableName = "",
                                IsChoice = true
                            };
                            SaveTableinfo(tempHtmlData);//此处既有表格信息、若不进行转存excel将大大提高效率
                            // Copy a string to the Windows clipboard.
                            System.Windows.Forms.Clipboard.SetDataObject(s);

                            // Start a new workbook in Excel.
                            var mObjExcel = new Excel.Application();
                            var mObjBooks = (Excel.Workbooks)mObjExcel.Workbooks;
                            var mObjBook = (Excel._Workbook)(mObjBooks.Add(MObjOpt));

                            // Paste the data starting at cell A1.
                            var mObjSheets = (Excel.Sheets)mObjBook.Worksheets;
                            var mObjSheet = (Excel._Worksheet)(mObjSheets.get_Item(1));
                            var mObjRange = mObjSheet.get_Range("A1", MObjOpt);
                            mObjSheet.Paste(mObjRange, false);

                            // Save the workbook and quit Excel.
                            FileInfo fi = new FileInfo(fileName);
                            var excelfilename = fi.Name.Replace(".htm", "table" + TableCount.ToString() + ".xlsx");//将存储格式改为PMID+table1.xlsx便于应用

                            var address = ExcelSavepath + excelfilename;
                            
                            mObjBook.SaveAs(address, MObjOpt, MObjOpt,
                                            MObjOpt, MObjOpt, MObjOpt, Excel.XlSaveAsAccessMode.xlNoChange,
                                            MObjOpt, MObjOpt, MObjOpt, MObjOpt);

                            mObjBook.Close(false, MObjOpt, MObjOpt);
                            mObjExcel.Quit();
                            
                            if (bind)
                            {
                                excelnum++;
                                excelList.Add(new ExcelFile { ID = excelnum, Path = address });
                            }
                            //count++;
                        }
                    }
                    TableCount++;
                    tempcount++;
                }

                System.Console.WriteLine(tempcount);
            }
        }

        private static void SaveTableinfo(HtmlData tempHtmlData)
        {

        }
    }
}
