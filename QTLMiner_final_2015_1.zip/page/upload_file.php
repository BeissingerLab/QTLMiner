
<?php
return 0;
?>