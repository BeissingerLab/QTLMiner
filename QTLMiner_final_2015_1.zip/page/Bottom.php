<html>
<head>
<style type="text/css">
#foot
{
	background-color: #e6e6e6;
	color: #77c;
    height: 35px;
    line-height: 15px;
    text-align: center;
	margin-bottom:-6px;
    clear:both;
    font-size:13px;
}
</style>
</head>
<body>
<div id="foot">&copy;2014&nbsp;neigae&nbsp;heilongjiang ICP prepared No.14004075-1<br><span>Northeast Institute of Geography and Agroecology, Chinese Academy of Sciences</span></div>
</body>
</html>
