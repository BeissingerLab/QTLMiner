<?php
//2014-10-11
//lidongye
?>
<?php 
	ob_end_clean();
	ob_implicit_flush(1);
	$root_path = $_SERVER['DOCUMENT_ROOT']."\\qtlminer";
	$local_path = "$root_path\\temp\\";
	$hostname = "www.soyomics.com/qtlminer";
	$keyword = $_GET["key"];
	$workpath = "test";
	$DataURL;
	
?>
<html>
<head>
<title>data show page</title>

<link rel="stylesheet" type="text/css" href="../../../js/EasyUI/themes/default/easyui.css"/>  
<link rel="stylesheet" type="text/css" href="../../../js/EasyUI/themes/icon.css"/>  
<script type="text/javascript" src="../../../js/EasyUI/jquery-1.8.0.min.js"></script>  
<script type="text/javascript" src="../../../js/EasyUI/jquery.easyui.min.js"></script>  
<script type="text/javascript" src="../../../js/EasyUI/locale/easyui-lang-en.js"></script>
<script type="text/javascript" src="../../../js/easyui-lang-xf.js"></script>
<link rel="stylesheet" type="text/css" href="../css/main.css"/> 

<script>
function Display_set(id, state)
{
	document.getElementById(id).style.display = state;
}
function Html_set(id, string)
{
	document.getElementById(id).innerHTML = string;
	
}
function changeCFdiv()
{
	//document.getElementById("div0").style.paddingTop = "20px";
	Display_set("div0", "none");
	Display_set("div1", "block");
}
</script>

</head>
<body>
	<form enctype="multipart/form-data" method="post" name="uploadForm">
	<input style="display:none" type="file" id="uploadFile" name="uploadFile"  onchange="if(div0.style.display=='none'){document.uploadForm.file1.value=this.value;document.uploadForm.file1.style.color='#555555';}else{document.uploadForm.file0.value=this.value;document.uploadForm.file0.style.color='#555555';}"/>
		
	<div class="CFdiv1 div1bg" id="div1">
		<div style="padding-top:20px">
		<a href="/qtlminer/page/"> <img width="134" height="48" border="0" title="QTLMiner" alt="home page" src="/qtlminer/image/logo.png"></a>
		</div>
		<div>
		<input class="CF1" type="text" readonly name="file1" onclick="document.uploadForm.uploadFile.click()" value="click here to choose file">
		<input class="UFsub1" type="submit" name="sub" value="upload file" />
		</div>
	</div>
	<div class="CFdiv0" id="div0">
		<div align="center" class="Logo">
			<a href="/qtlminer/page/"> <img width="384" height="128" border="0" title="QTLMiner" alt="home page" src="/qtlminer/image/logo.png"></a>
		</div>
		<div style="padding-bottom:2px;padding-top:10px">
			<input class="CF0" type="text" readonly name="file0" onclick="document.uploadForm.uploadFile.click()" value="click here to choose file">
		</div>
		<div style="padding-top:15px">
			<input class="UFsub0" type="submit" name="sub" value="upload file" />
			<input class="selectbut" type="button" name="but_sel" value="select file" onclick="document.uploadForm.uploadFile.click()" />
		</div>
	<section align="center" class="container press-coverage">
		<div class="grid">
	        <div class="col col--1-of-4">
	          <a href="/qtlminer/page/manual.php" target="_blank"><img src="/qtlminer/image/logo1.png" alt="Manual"></a>
	        </div>
	        <div class="col col--1-of-4">
	          <a href="/qtlminer/page/instruction.php" target="_blank"><img src="/qtlminer/image/logo1.png" alt="Instruction"></a>
	        </div>
	        <div class="col col--1-of-4">
	          <a href="http://www.soyomics.com/qtldatabase/" target="_blank"><img src="/qtlminer/image/logo1.png" alt="soybean QTL database"></a>
	        </div>
       	 	</div>
	</section>
	</div>
	</form>
	<div id="Progress" class="Progress" style="display:none">
		<p id="ProgressText">Progress</p>
	</div>
<?php
if($_POST['sub'])
{
	echo "<script>changeCFdiv();</script>";
	ob_flush();
	flush();
	Predeal();
}
else if($keyword != "")
{
	echo "<script>changeCFdiv();</script>";
	if(!is_dir("$local_path$keyword"))
	{
		Progressshow("your key:$keyword<br/>you input wrong key value or it's expired, please check it");
	}
	else
	{
		outputdata("$keyword");
	}
}
?>

<?php //function 

//make dir
function mk_dir(){
	$dir = randName();
	global $local_path;
	//echo "tmp_path $local_path <br/> dir: $dir<br/>";
	while(is_dir($local_path.$dir))
	{
		$dir = randName();
	}
	
	if(!mkdir($local_path.$dir,0777,true))
	{
		echo "mkdir false!<br/>";
	}
	return $dir;
}
//get Ext
function getExt($file) {  
    $tmp = explode('.',$file);
    return end($tmp);
}
//random string
function randName() {
	$str = 'abcdefghijklmnopqrstuvwxyz123456789';
    return substr(str_shuffle($str),0,6);  
}
function gettime()
{
	global $local_path, $workpath;
	$dir = opendir("$local_path$workpath\\Unzip\\");
	$sizeResult = 0;
	$num = 0;
	while (false!==($file = readdir($dir)))
	{
		if(preg_match("/\.pdf$/", $file))
		{
			//echo "$local_path$workpath\\Unzip\\$file";
            $sizeResult += filesize("$local_path$workpath\\Unzip\\$file");
            $num ++;
		}
	}
	closedir($dir);
	return array($num, $sizeResult/1024/360);
}
//deal Data, get Form data
function dealdata($upfile)
{
	//echo "start move file<br/>";
	//���ϴ�����ʱ�ļ��ƶ������Ŀ¼��
	global $local_path, $root_path, $workpath, $DataURL, $hostname;
	$workpath = mk_dir();
	$newpath = $local_path.$workpath.'\\';
	$name=$upfile["name"];//�ϴ��ļ����ļ���
	$size=$upfile["size"];//�ϴ��ļ��Ĵ�С
	$tmp_name=$upfile["tmp_name"];//�ϴ��ļ�����ʱ���·��
	$newname = randName(). '.' .getExt($name);

	if(!move_uploaded_file($tmp_name,$newpath.$newname))
	{
		echo 'move false';
		return -1;
	}
	$file=$newpath.$newname;

	//echo "Upload successful,start deal data...</br>";
	if(preg_match("/\.pdf$/", $file))
	{
		mkdir("$newpath\\Unzip\\", 0777,true);
		copy($file, "$newpath\\Unzip\\$name");
	}
	else
	{
		exec("D:\\HaoZip\\HaoZipC.exe e -y $file -o$newpath\\Unzip\\");
	}
	$result = gettime();
	$filenum = $result[0];
	$time = round($result[1])+1;
	$DataURL = "<a href=/QTLminer/page/?key=$workpath>$hostname/?key=$workpath</a>";
	$stames = "total upload $filenum pdf files, the estimated time is $time min<br/>you can visit the data at $DataURL after deal";
	Progressshow($stames);
	$fp = fopen("$local_path$workpath\\working","w");
	fwrite($fp, $stames);
	fclose($fp);
	//��ʼ��ִ̨��
	ignore_user_abort(true);
	set_time_limit(0);
	exec("$root_path\\Program\\Deal.bat $root_path $newpath >nul");
	
	/*
	exec("D:\\Haozip\\HaoZipC.exe a -tzip $newpath\\PDF.zip $newpath\\Unzip\\*.pdf");
	//echo "$root_path\\Program\\Sendfile\\Client.exe $local_path$workpath\\<br/>";
	exec("$root_path\\Program\\Sendfile\\Client.exe $newpath\\");
	exec("D:\\HaoZip\\HaoZipC.exe e -y $newpath\\htm.zip -o$newpath\\htm\\");
	//echo "$root_path\\Program\\ReadQTLData\\ReadQTLData.exe $local_path$workpath\\<br/>";
	exec("$root_path\\Program\\ReadQTLData\\ReadQTLData.exe $newpath\\");
	*/
	return 0;
}


function PreDeal()
{
	global $local_path, $root_path, $workpath;
	Progressshow("please waiting for uploading file...");
	if(is_uploaded_file($_FILES['uploadFile']['tmp_name'])){ //
		$upfile=$_FILES["uploadFile"];
		//��ȡ���������ֵ
		$type=$upfile["type"];//�ϴ��ļ�������
		$tmp_name=$upfile["tmp_name"];
		//�ж��Ƿ�Ϊָ������ļ�
		$okType=false;

		if(preg_match("/zip|rar|pdf/i", $type))
		{
			$okType = true;	
		}
		
		if($okType){

			$error=$upfile["error"];//�ϴ���ϵͳ���ص�ֵ
			if($error==0){
				if(dealdata($upfile))
				{
					Progressshow("error!");
				}
				Progressshow("end");
				outputdata($workpath);
				//echo '<input type="submit" name="DownLoadData" value="DownLoadData">';

				
			}else{
					unlink($tmp_name);
					Progressshow("error $error.something wrong when uploadfile.");
			}
		}else{
			unlink($tmp_name);
			Progressshow("please upload rar,zip or pdf file!");
		}
	}else{
		unlink($tmp_name);
		Progressshow("no file");
		return ;
	}
}

//�����������Ϊ����
function outputdata($keyword)
{
	global $local_path, $hostname;
//	echo $hostname;
	$bool_out = 1;
	set_time_limit(0);
	while(is_file("$local_path$keyword\\working"))
	{

		if($bool_out)
		{
			$mes = fopen("$local_path$keyword\\working", "r");
			
			$sta = fgets($mes);
			Progressshow($sta);
			fclose($mes);
			$bool_out = 0;
		}
		sleep(1);
	}
//echo "$local_path$keyword\\working\n";
	$file = "$local_path$keyword\\finaldata\\FinalData.txt";
	if(is_file($file)){
		echo "<div style=\"padding-left:10%;\"><p>Result:(you can visit this form in 10 days at:<a href=/QTLminer/page/?key=$keyword>$hostname/?key=$keyword</a>)</p></div>";
		//Output a line of the file until the end is reached
		echo '<div class="table_show"><div  id="dg"></div></div>';
		show_table($file);
		if(!is_file("$local_path$keyword\\FinalData.zip"))
		{
			exec("D:\\Haozip\\HaoZipC.exe a -tzip $local_path$keyword\\FinalData.zip $local_path$keyword\\finaldata\\*.txt $local_path$keyword\\finaldata\\*.xlsx");
		}
		echo "<div style='padding-left:10%;padding-top:20px;'><A HREF=\"/QTLminer/temp/$keyword/FinalData.zip\">Final Data Download</A><br/>";
		//echo '<script type="text/javascript">setInterval("setwidth();", 80);</script>';
		//require 'autoheight.php';
	}
	else{
		echo 'read FinalData false!</br>';
	}
}
function Progressshow($string)//��Ϣ��ʾ
{
	if($string == "end")
    {
    	echo "<script>Display_set(\"Progress\", \"none\");</script>";	
    }
    else
    {
    	echo "<script>Display_set(\"Progress\", \"block\");</script>";
    //echo "$string <br/>";
		echo "<script>Html_set(\"ProgressText\", \"$string\");</script>";
    //str_pad(' ', 1024).
    }
    ob_flush();
    flush();
}
?>
<script>

var bodyfrm = ( document.compatMode.toLowerCase()=="css1compat" ) ? document.documentElement : document.body;
var adst = document.getElementById("div_tbhead").style;
function moveR(){if((bodyfrm.scrollTop - 190)>0){adst.top = (bodyfrm.scrollTop - 160)+"px";}else{adst.top="";}}
setInterval("moveR();", 100);
function closead()
{
	adst.display='none';
}
</script>
<?php require 'autoheight.php';?>
</body>
</html>
<?php
function show_table($filename)
{
        $file = fopen($filename,"r") or die("Unable to Open File!");
        $content =fgets($file);
        $content = str_replace("/","-",$content);
        $content = str_replace("\n", "", $content);
        $content = str_replace("\r", "", $content);
        $columns_word = explode("\t", $content);
        $flag = 0;
        echo "\n<script type=\"text/javascript\">\n
        var columns1= [[";
        foreach ($columns_word as $id)
        {
                if($flag)
                        echo ",";
                else
                        $flag = 1;
                        echo "{ field:'$id', title:'$id', width:130, align:'center', sortable:true}";
        }
        echo "]];\n";
        echo "var griddata1 = {'rows':[";
	$flag = 0;
        while(!feof($file))
        {	
                $content1 = fgets($file);
                $content1 = str_replace("\n", "", $content1);
                $content1 = str_replace("\r", "", $content1);
                $columns_word1 = explode("\t", $content1);
                $th = count($columns_word1);
                if($th<2)
		{
                        break;
                }
		else
                {
                        if($flag)
                                echo",";
                        else
                                $flag = 1;
                        echo "{";
                        $flag_td = 0;
                        for($i=0;$i<$th;$i++)
                        {
                                if($flag_td)
                                        echo ",";
                                else
                                        $flag_td = 1;
                                echo "'".$columns_word[$i]."':'".$columns_word1[$i]."'";
                        }
                        echo "}";
                }
        }
        echo "]};\n";
        fclose($file);
        echo "$(function(){
                $(\"#dg\").datagrid( 
                {
        //      url:'./DatGride_Getdata.php?database=$database&table=$datatable',
                collapsible:true,
                height: 475,
                border: true,
                remoteSort:false,		//
		title:'Result',
                rownumbers:true,        //�к�
                singleSelect:true,      //��ѡ
                fitColumns:false,       //��С����Ӧ
                striped:true,   //?
                columns:columns1,
                onLoadSuccess:function(data){
                                        //document.getElementById(\"xf\").src
                                        $(this).datagrid('doCellTip',{'max-width':'400px','delay':300});
                                },
                /*onDblClickRow:function(rowIndex, rowData){
                        $.messager.confirm('Confirm','Are you sure you want to delete record?',function(r)
                        {
                                if (r)
                                {
                                        $('#dg').datagrid('deleteRow', rowIndex);
                                        $.messager.alert('delete success',rowData['". $th[0][Field]."']+rowData['". $th[1][Field]."']);         
                                }
                        });
        
                        }*/
                });
                $('#dg').datagrid('loadData',griddata1);

        });
    ";
        echo "</script>";
}
?>