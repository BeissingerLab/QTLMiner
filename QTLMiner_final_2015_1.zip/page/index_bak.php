<?php 
	ob_end_clean();
	ob_implicit_flush(1);
	$root_path = $_SERVER['DOCUMENT_ROOT']."\\qtlminer";
	$local_path = "$root_path\\temp\\";
	$hostname = "www.soyomics.com/qtlminer";
	$keyword = $_GET["key"];
	$workpath = "test";
	$DataURL;
	
?>
<html>
<head>
<title>data show page</title>

<link rel="stylesheet" type="text/css" href="../../../js/EasyUI/themes/default/easyui.css"/>  
<link rel="stylesheet" type="text/css" href="../../../js/EasyUI/themes/icon.css"/>  
<script type="text/javascript" src="../../../js/EasyUI/jquery-1.8.0.min.js"></script>  
<script type="text/javascript" src="../../../js/EasyUI/jquery.easyui.min.js"></script>  
<script type="text/javascript" src="../../../js/EasyUI/locale/easyui-lang-en.js"></script>
<script type="text/javascript" src="../../../js/easyui-lang-xf.js"></script>

<script>
function Display_set(id, state)
{
	document.getElementById(id).style.display = state;
}
function Html_set(id, string)
{
	document.getElementById(id).innerHTML = string;
	
}
function changeCFdiv()
{
	//document.getElementById("div0").style.paddingTop = "20px";
	Display_set("div0", "none");
	Display_set("div1", "block");
}
</script>
<style type="text/css">
body
{
	font-family:Arial;
}
td
{
	text-align:center;
}
.CF0
{
	color:999999;
	font-weight:bold;
	width:512px;
	height:25px;
	line-height:27px;
	overflow:hidden;
}
.CF1
{
	position: relative;
	width:400px;
	height:33px;
	padding:3px;
	color:999999;
  	font-weight:bold;
}
.UFsub0
{
	height:25px;
	width:140px;
	
	text-align:center;
	font-family:arial,verdana,sans-serif, '������';
	font-weight:bold;
	font-size:15px;
	background:#D4D4D4;
	color:#888;
	text-decoration:none;
	border: 1px solid #A4A4A4;
	cursor:pointer;
}
.UFsub1
{
	height:33px;
	width:100px;
	text-align:center;
	font-family:arial,verdana,sans-serif, '������';
	font-weight:bold;
	font-size:15px;
	background:#D4D4D4;
	color:#888;
	text-decoration:none;
	border: 1px solid #A4A4A4;
	cursor:pointer;
}
.UFsub1:hover{background:#E4E4E4;color:#666666;}
.UFsub0:hover{background:#E4E4E4;color:#666666;}
.selectbut:hover{background:#E4E4E4;color:#666666;}
.selectbut
{
	height:25px;
	width:140px;
	margin-left:45px;
	
	text-align:center;
	font-family:arial,verdana,sans-serif, '������';
	font-weight:bold;
	font-size:15px;
	background:#D4D4D4;
	color:#888888;
	text-decoration:none;
	border: 1px solid #A4A4A4;
	cursor:pointer;
}
.CFdiv0
{
	position: relative;
	width:100%;
	text-align:center;
	padding-top:10%;
	margin-left: auto;
	margin-right: auto;
}
.CFdiv1
{
	display:none;
	position: relative;
	width:100%;
	height:83px;
	line-height:85px;
	overflow:hidden;
}
.div1bg
{
	background-color:#f1f1f1;
	border-bottom:1px solid #666;
	border-color:#e5e5e5;
}
.CFdiv1 div
{
    float:left;
    height:75;
    padding-left:10px;
}

.Logo
{
	position: relative;
	text-align:center;
	margin-left: auto;
	margin-right: auto;
}
.Progress
{
	
}
.formdiv
{
	width:80%;
	text-align:center;
	padding:20px;
	margin-left: auto;
	margin-right: auto;
	overflow-x:scroll;
	font-family:Arial;
}
#div_tbhead
{
	width:3800px;
	position: relative;
}
.div_tbbody
{
	width:3800px;
}
.headtb
{
	table-layout: fixed;
	border-collapse:collapse;
	border:none;
	font-weight:bold;
}
.headtb td
{
        word-break: break-all;
        word-wrap:break-word;
        width:198px;
        height:30px;
        border:solid #97FFDF 3px;
}
.datatb
{
	border:1px;
	table-layout:fixed;
}
.datatb td
{
	word-break: break-all;
	word-wrap:break-word;
	width:199px;
}
</style>

</head>
<body>
	<form enctype="multipart/form-data" method="post" name="uploadForm">
	<input style="display:none" type="file" id="uploadFile" name="uploadFile"  onchange="if(div0.style.display=='none'){document.uploadForm.file1.value=this.value;document.uploadForm.file1.style.color='#555555';}else{document.uploadForm.file0.value=this.value;document.uploadForm.file0.style.color='#555555';}"/>
		
	<div class="CFdiv1 div1bg" id="div1">
		<div style="padding-top:20px">
		<a href="/qtlminer/page/"> <img width="134" height="48" border="0" title="QTLMiner" alt="home page" src="/qtlminer/image/logo.png"></a>
		</div>
		<div>
		<input class="CF1" type="text" readonly name="file1" onclick="document.uploadForm.uploadFile.click()" value="click here to choose file">
		<input class="UFsub1" type="submit" name="sub" value="upload file" />
		</div>
	</div>
	<div class="CFdiv0" id="div0">
		<div align="center" class="Logo">
			<a href="/qtlminer/page/"> <img width="384" height="128" border="0" title="QTLMiner" alt="home page" src="/qtlminer/image/logo.png"></a>
		</div>
		<div style="padding-bottom:2px;padding-top:10px">
			<input class="CF0" type="text" readonly name="file0" onclick="document.uploadForm.uploadFile.click()" value="click here to choose file">
		</div>
		<div style="padding-top:15px">
			<input class="UFsub0" type="submit" name="sub" value="upload file" />
			<input class="selectbut" type="button" name="but_sel" value="select file" onclick="document.uploadForm.uploadFile.click()" />
		</div>
	</div>
	</form>
	<div id="Progress" class="Progress" style="display:none">
		<p id="ProgressText">Progress</p>
	</div>
<?php
if($_POST['sub'])
{
	echo "<script>changeCFdiv();</script>";
	ob_flush();
	flush();
	Predeal();
}
else if($keyword != "")
{
	echo "<script>changeCFdiv();</script>";
	if(!is_dir("$local_path$keyword"))
	{
		Progressshow("your key:$keyword<br/>you input wrong key value or it's expired, please check it");
	}
	else
	{
		outputdata("$keyword");
	}
}
?>

<?php //function 

//make dir
function mk_dir(){
	$dir = randName();
	global $local_path;
	//echo "tmp_path $local_path <br/> dir: $dir<br/>";
	while(is_dir($local_path.$dir))
	{
		$dir = randName();
	}
	
	if(!mkdir($local_path.$dir,0777,true))
	{
		echo "mkdir false!<br/>";
	}
	return $dir;
}
//get Ext
function getExt($file) {  
    $tmp = explode('.',$file);
    return end($tmp);
}
//random string
function randName() {
	$str = 'abcdefghijklmnopqrstuvwxyz123456789';
    return substr(str_shuffle($str),0,6);  
}
function gettime()
{
	global $local_path, $workpath;
	$dir = opendir("$local_path$workpath\\Unzip\\");
	$sizeResult = 0;
	$num = 0;
	while (false!==($file = readdir($dir)))
	{
		if(preg_match("/\.pdf$/", $file))
		{
			//echo "$local_path$workpath\\Unzip\\$file";
            $sizeResult += filesize("$local_path$workpath\\Unzip\\$file");
            $num ++;
		}
	}
	closedir($dir);
	return array($num, $sizeResult/1024/360);
}
//deal Data, get Form data
function dealdata($upfile)
{
	//echo "start move file<br/>";
	//���ϴ�����ʱ�ļ��ƶ������Ŀ¼��
	global $local_path, $root_path, $workpath, $DataURL, $hostname;
	$workpath = mk_dir();
	$newpath = $local_path.$workpath.'\\';
	$name=$upfile["name"];//�ϴ��ļ����ļ���
	$size=$upfile["size"];//�ϴ��ļ��Ĵ�С
	$tmp_name=$upfile["tmp_name"];//�ϴ��ļ�����ʱ���·��
	$newname = randName(). '.' .getExt($name);

	if(!move_uploaded_file($tmp_name,$newpath.$newname))
	{
		echo 'move false';
		return -1;
	}
	$file=$newpath.$newname;

	//echo "Upload successful,start deal data...</br>";
	if(preg_match("/\.pdf$/", $file))
	{
		mkdir("$newpath\\Unzip\\", 0777,true);
		copy($file, "$newpath\\Unzip\\$name");
	}
	else
	{
		exec("D:\\HaoZip\\HaoZipC.exe e -y $file -o$newpath\\Unzip\\");
	}
	$result = gettime();
	$filenum = $result[0];
	$time = round($result[1])+1;
	$DataURL = "<a href=/QTLminer/page/?key=$workpath>$hostname/?key=$workpath</a>";
	$stames = "total upload $filenum pdf files, the estimated time is $time min<br/>you can visit the data at $DataURL after deal";
	Progressshow($stames);
	$fp = fopen("$local_path$workpath\\working","w");
	fwrite($fp, $stames);
	fclose($fp);
	//��ʼ��ִ̨��
	ignore_user_abort(true);
	set_time_limit(0);
	exec("$root_path\\Program\\Deal.bat $root_path $newpath >nul");
	
	/*
	exec("D:\\Haozip\\HaoZipC.exe a -tzip $newpath\\PDF.zip $newpath\\Unzip\\*.pdf");
	//echo "$root_path\\Program\\Sendfile\\Client.exe $local_path$workpath\\<br/>";
	exec("$root_path\\Program\\Sendfile\\Client.exe $newpath\\");
	exec("D:\\HaoZip\\HaoZipC.exe e -y $newpath\\htm.zip -o$newpath\\htm\\");
	//echo "$root_path\\Program\\ReadQTLData\\ReadQTLData.exe $local_path$workpath\\<br/>";
	exec("$root_path\\Program\\ReadQTLData\\ReadQTLData.exe $newpath\\");
	*/
	return 0;
}


function PreDeal()
{
	global $local_path, $root_path, $workpath;
	Progressshow("please waiting for uploading file...");
	if(is_uploaded_file($_FILES['uploadFile']['tmp_name'])){ //
		$upfile=$_FILES["uploadFile"];
		//��ȡ���������ֵ
		$type=$upfile["type"];//�ϴ��ļ�������
		$tmp_name=$upfile["tmp_name"];
		//�ж��Ƿ�Ϊָ������ļ�
		$okType=false;

		if(preg_match("/zip|rar|pdf/i", $type))
		{
			$okType = true;	
		}
		
		if($okType){

			$error=$upfile["error"];//�ϴ���ϵͳ���ص�ֵ
			if($error==0){
				if(dealdata($upfile))
				{
					Progressshow("error!");
				}
				Progressshow("end");
				outputdata($workpath);
				//echo '<input type="submit" name="DownLoadData" value="DownLoadData">';

				
			}else{
					unlink($tmp_name);
					Progressshow("error $error.something wrong when uploadfile.");
			}
		}else{
			unlink($tmp_name);
			Progressshow("please upload rar,zip or pdf file!");
		}
	}else{
		unlink($tmp_name);
		Progressshow("no file");
		return ;
	}
}

//�����������Ϊ����
function outputdata($keyword)
{
	global $local_path, $hostname;
//	echo $hostname;
	$bool_out = 1;
	set_time_limit(0);
	while(is_file("$local_path$keyword\\working"))
	{
		if($bool_out)
		{
			$mes = fopen("$local_path$keyword\\working", "r");
			$sta = fgets($mes);
			Progressshow($sta);
			fclose($mes);
			$bool_out = 0;
		}
		sleep(1);
	}
	$file = "$local_path$keyword\\finaldata\\FinalData.txt";
	if(is_file($file)){
		$fin = fopen($file, "r") or exit("Unable to open file!");
		echo "<div style=\"padding-left:10%;\"><p>Result:(you can visit this form in 10 days at:<a href=/QTLminer/page/?key=$keyword>$hostname/?key=$keyword</a>)</p></div>";
		//Output a line of the file until the end is reached
		echo '<div class="formdiv">';//<div class="divTb">';
		echo '<div id="div_tbhead"><table id="tbhead" class="headtb">';//style="border:1px; table-layout:fixed;margin:auto;"
		$DataNum = 0;
		//echo "<ul id=\"table_ul1\" bgcolor = \"#66CCFF\"><li>".str_replace('	', '</li><li>',fgets($fin))."</li></ul><br/>";
		echo "<tr bgcolor = \"#66CCFF\"><td>".str_replace('	', '</td><td>',fgets($fin))."</td></tr>";
		
		echo '</table></div>';
		
		echo '<div class="div_tbbody"><table id="tbdata" class="datatb">';
		while(1)
  		{
  			$bgcolor = $DataNum++%2==0 ? " " : ' bgcolor = "#CCFFFF"' ;
			echo "<tr $bgcolor><td>".str_replace('	', '</td><td>',fgets($fin))."</td></tr>";
			if(feof($fin))
  			break ;
  		}
		fclose($fin);
		if(!is_file("$local_path$keyword\\FinalData.zip"))
		{
			exec("D:\\Haozip\\HaoZipC.exe a -tzip $local_path$keyword\\FinalData.zip $local_path$keyword\\finaldata\\*.txt $local_path$keyword\\finaldata\\*.xlsx");
		}
		echo  "</table></div></div>";
		echo "<A HREF=\"/QTLminer/temp/$keyword/FinalData.zip\">Final Data Download</A><br/>";
		//echo '<script type="text/javascript">setInterval("setwidth();", 80);</script>';
		//require 'autoheight.php';
	}
	else{
		echo 'read FinalData false!</br>';
	}
}
function Progressshow($string)//��Ϣ��ʾ
{
	if($string == "end")
    {
    	echo "<script>Display_set(\"Progress\", \"none\");</script>";	
    }
    else
    {
    	echo "<script>Display_set(\"Progress\", \"block\");</script>";
    //echo "$string <br/>";
		echo "<script>Html_set(\"ProgressText\", \"$string\");</script>";
    //str_pad(' ', 1024).
    }
    ob_flush();
    flush();
}
?>
<script>
/*
function setwidth(){
	for(var i=0;i<document.getElementById("tbdata").rows[0].cells.length;i++)
	{
	document.getElementById("tbhead").rows[0].cells[i].width=document.getElementById("tbdata").rows[0].cells[i].offsetWidth+"px";
	}
}
*/

var bodyfrm = ( document.compatMode.toLowerCase()=="css1compat" ) ? document.documentElement : document.body;
var adst = document.getElementById("div_tbhead").style;
function moveR(){if((bodyfrm.scrollTop - 190)>0){adst.top = (bodyfrm.scrollTop - 160)+"px";}else{adst.top="";}}
setInterval("moveR();", 100);
function closead()
{
	adst.display='none';
}
</script>
<?php require 'autoheight.php';?>
</body>
</html>
<?php
function show_table($filepath)
{
        $filename = $filepath;
        $file = fopen($filename,"r") or die("Unable to open file!");
        $content =fgets($file);
        $content = str_replace("/","-",$content);
        $content = str_replace("\n", "", $content);
        $content = str_replace("\r", "", $content);
        $columns_word = explode("\t", $content);
        $flag = 0;
        echo "\n<script type=\"text/javascript\">\n
        var columns1= [[";
        foreach ($columns_word as $id)
        {
                if($flag)
                        echo ",";
                else
                        $flag = 1;
                        echo "{ field:'$id', title:'$id', width:200, align:'center', sortable:true}";
        }
        echo "]];\n";
        echo "var griddata1 = {'rows':[";
        $flag = 0;
        while(!feof($file))
        {
                $content1 = fgets($file);
                $content1 = str_replace("\n", "", $content1);
                $content1 = str_replace("\r", "", $content1);
                $columns_word1 = explode("\t", $content1);
                $th = count($columns_word1);
                if($th<2)
                        break;
                else
                {
                        if($flag)
                                echo",";
                        else
                                $flag = 1;
                        echo "{";
                        $flag_td = 0;
                        for($i=0;$i<$th;$i++)
                        {
                                if($flag_td)
                                        echo ",";
                                else
                                        $flag_td = 1;
                                echo "'".$columns_word[$i]."':'".$columns_word1[$i]."'";
                        }
                        echo "}";
                }
        }
        echo "]};\n";
        fclose($file);
        echo "$(function(){
                $(\"#dg\").datagrid( 
                {
        //      url:'./DatGride_Getdata.php?database=$database&table=$datatable',
                collapsible:true,
                height: 475,
                border: true,

                rownumbers:true,        //�к�
                singleSelect:true,      //��ѡ
                fitColumns:false,       //��С����Ӧ
                striped:true,   //?
                columns:columns1,
                onLoadSuccess:function(data){
                                        //document.getElementById(\"xf\").src
                                        $(this).datagrid('doCellTip',{'max-width':'400px','delay':300});
                                },
                /*onDblClickRow:function(rowIndex, rowData){
                        $.messager.confirm('Confirm','Are you sure you want to delete record?',function(r)
                        {
                                if (r)
                                {
                                        $('#dg').datagrid('deleteRow', rowIndex);
                                        $.messager.alert('delete success',rowData['". $th[0][Field]."']+rowData['". $th[1][Field]."']);         
                                }
                        });
        
                        }*/
                });
                $('#dg').datagrid('loadData',griddata1);

        });
    ";
        echo "</script>";
}
?>