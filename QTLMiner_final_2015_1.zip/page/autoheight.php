<script defer type="text/javascript">
if(top.location != location)
{
	document.getElementById("none_div").innerHTML = '<iframe id="b_iframe" width="100%" src="http://www.soyomics.com/soyomics/agent.html" style="display:none"></iframe>';
	//document.getElementById("none_div").innerHTML = '<iframe id="b_iframe" width="100%" src="http://192.168.2.178/qtlminer/page/agent.html" style="display:none"></iframe>';
	var b_height = Math.max(document.body.scrollHeight,document.body.clientHeight); 
	var b_iframe = document.getElementById("b_iframe");
	b_iframe.src = b_iframe.src+"#"+b_height; 
}
</script> 
