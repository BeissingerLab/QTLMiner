<html>
<head>
<title>QTL Website</title>
</head>
<body>
<?php 
$a="Hello,Welcome To ldy's First Website!";
echo $a;
?>


</body>