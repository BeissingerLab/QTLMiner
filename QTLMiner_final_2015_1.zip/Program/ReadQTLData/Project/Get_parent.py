#encoding=utf-8
import sys,io,os
import string
import re
#z = 0

#def deal_l(x,list_c,list_res):
	#p = re.compile(r'\(')
#			list_first=p.split(a.string)
#			list_second=list_first[1].split(' ')
#			list_third = list_second[1].split(')')
#			list_forth = list_third[0].split('-')
#			if len(list_forth)=2:
#				list_res.append(list_forth[0])
#			elif len(list_forth)>2:
#				for xx in range(0,len(list_forth)-2):
#					list_res.append(list_forth[xx])
#					if xx != (len(list_forth)-2):
#						list_res.append('-')

#dir_now = os.getcwd()
#list_index =  os.listdir(dir_now+'/table_deal/')

#	list_temp = list_index[iii].split('.')
#	list_index[iii] = list_temp[0]+'.parent'


def definition():
	pattern1 = re.compile(r'prep_(between|of)\(cross-(\d)(.+)\)')
	pattern2 = re.compile(r'prep_from\(derived-(\d)(.+)\)')
	pattern3 = re.compile(r'prep_of\(allele-(\d)(.+)\)')
	pattern4 = re.compile(r'prep_of\(mapping-(\d)(.+)\)')
	pattern5 = re.compile(r'prep_of\(hybridization-\d.+\)')
	return pattern1,pattern2,pattern3,pattern4,pattern5



#chars = []
#flag = 0

def rule_find(sentence,dir_now,filename):
	filenames = ''
#	for ii in range(0,len(list_index)):
	dir_deal = dir_now
	#file_res = open(dir_deal+list_index[i],'w',1)
		#file = open(dir_now+'/table_deal/'+list_index[ii],'r',1)
		#file = open(file_list)
		#list_pro = file.readlines()
		#for a in range(0,len(list_pro)):          #split sentences
			#list_num = list_pro[a].split()
	list_res=[]
		#	file_temp = open('/home/biolo/Desktop/123','w',1)
	gx = re.search('(\w+)\ ?×\ (\w+)',sentence)
	bx = re.search(r'‘(.+)’\ ·\ (\w+)',sentence)
	hx = re.search(r'(\w+?-?\w+?-?\w+)\ ·\ (\w+-?\w+?-?\w+?)',sentence)
	dx = re.search(r'‘(.+)’\ ?and\ ?‘(.+)’',sentence)
	fx = re.search(r'(\w+\ ?\d+?)\ ￡\ (\w+\ ?\d+?)',sentence)
	cx = re.search(r'(\w+?-?\w+?-?\w+)\ ?×\ ?(\w+)',sentence)
	ex = re.search(r'(\w+?-?\w+?-?\w+)\ ·\ (\w+\ \d+?\ )',sentence)
	ix = re.search(r'(\w+?-?\w+?-?\w+)\ &\ (\w+-?\w+?-?\w+?)',sentence)
	jx = re.search(r'(\w+)\ (\w+-?\w+?-?\w+)\ 9\ (\w+-?\w+?-?\w+?)\ (\w+-?\w+?-?\w+?)?',sentence)
	kx = re.search(r'’(.+)’\ and\ ‘(.+)’',sentence)
	lx = re.search(r'(\w+)\ (\w+.\w+)\ 9\ (\w+-?\w+?-?\w+?)\ ?(\w+)?',sentence)
	if cx:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames  = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,cx.group(1)+' * '+cx.group(2)
		return 1
	elif bx:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,bx.group(1)+' * '+bx.group(2)
		return 1
	elif dx:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,dx.group(1)+' * '+dx.group(2)
		return 1
	elif ex:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames  = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,ex.group(1)+' * '+ex.group(2)
		return 1
	elif fx:	
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,fx.group(1)+' * '+fx.group(2)
		return 1
	elif gx:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames  = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,gx.group(1)+' * '+gx.group(2)
		return 1
	elif hx:	
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames  = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,hx.group(1)+' * '+hx.group(2)
		return 1
	elif ix:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,ix.group(1)+' * '+ix.group(2)
		return 1
	elif jx:
		for number in range(1,5):
			if type(jx.group(number)) != type(None):
				string_check = jx.group(number)
				if not string_check.islower():
					list_res.append(string_check)
		if len(list_res)>=2:
			list_temp = filename.split('.')
			if len(list_temp) > 2:
				for i in range(0,len(list_temp)-1):
					filenames = filenames + list_temp[i]+'.'
				filenames = filenames + 'parent'
			else :
				filenames = list_temp[0]+'.parent'
			file_res = open(dir_deal+filenames,'w',1)		
		if len(list_res) == 2:
			print >> file_res,list_res[0]+' * '+list_res[1]
		if len(list_res) == 3:
			print >> file_res,list_res[1]+' * '+list_res[2]
		if len(list_res) == 4:
			print >> file_res,list_res[1]+' * '+list_res[3]
		return 1
	elif kx:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'
		file_res = open(dir_deal+filenames,'w',1)
		print >> file_res,kx.group(1)+' * '+kx.group(2)
		return 1
	
	elif lx:
		for number in range(1,5):
			if type(lx.group(number)) != type(None):
				string_check = lx.group(number)
				if not string_check.islower():
					list_res.append(string_check)
		if len(list_res)>=2:
			list_temp = filename.split('.')
			if len(list_temp) > 2:
				for i in range(0,len(list_temp)-1):
					filenames = filenames + list_temp[i]+'.'
				filenames = filenames + 'parent'
			else :
				filenames = list_temp[0]+'.parent'
			file_res = open(dir_deal+filenames,'w',1)
		if len(list_res)==2:
			print >> file_res,list_res[0]+' * '+list_res[1]
		elif len(list_res)==3:
			print >> file_res,list_res[0]+' '+list_res[1]+' * '+list_res[2]
		elif len(list_res)==4:
			print >> file_res,list_res[0]+' '+list_res[1]+' * '+list_res[2]+' '+list_res[3]
		return 1
	return 0
		

		#file_temp.write(list_pro[a])
		#print list_index[i]
		#os.system('bash ~/Desktop/stanford-parser-full-2014-01-04/lexparser.sh /home/biolo/Desktop/123'+' > ~/Desktop/Solusion_parent/temp.txt')

def parser_find(pattern1,pattern2,pattern3,pattern4,pattern5,dir_deal,filename,sentence,addr):
	list_res = []
	file1 = open(addr+'\\parser','r',1)
	list_c = file1.readlines()
	filenames = ''
	#if a==2:
		#exit(0)
	#将parse运行后的文件读入分割成若干行


	for i in range(0,len(list_c)-1):
			#print list_c[i]
		ax=pattern1.match(list_c[i])
			#b=re.match('','')
		if ax:
			p = re.compile(r'\(')
			list_first=p.split(ax.string)
			list_second=list_first[1].split(' ')
			list_third = list_second[1].split(')')
			list_forth = list_third[0].split('-')
			if len(list_forth)==2:
				list_res.append(list_forth[0])
			elif len(list_forth)>2:
				stringa=''
				for xx in range(0,len(list_forth)-1):
					stringa = stringa + list_forth[xx]
					if xx != (len(list_forth)-2):
						stringa = stringa+'-'
				list_res.append(stringa)


	if len(list_res)==1:
		for i in range(0,len(list_c)-1):
			a_next = re.match('dep\('+list_res[0]+'-(\d)(.+)\)',list_c[i])
			if a_next:
				p = re.compile(r'\(')
				list_first=p.split(a_next.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa=''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa+'-'
					list_res.append(stringa)
	

	if len(list_res)==1:
		for i in range(0,len(list_c)-1):
			a_next = re.match('prep_with\(derived-(\d)(.+)\)',list_c[i])
			if a_next:
				p = re.compile(r'\(')
				list_first=p.split(a_next.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa = ''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa + '-'
					list_res.append(stringa)

	if len(list_res)==0:
		for i in range(0,len(list_c)-1):
			temp_2 = pattern2.match(list_c[i])
			temp_3 = pattern3.match(list_c[i])
			temp_4 = pattern4.match(list_c[i])
			temp_5 = pattern5.match(list_c[i])
			if temp_2:
				p = re.compile(r'\(')
				list_first=p.split(temp_2.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa = ''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa + '-'
					list_res.append(stringa)
					for n in range(0,i-1):
						a_next = re.match('poss\('+list_third[0]+'-(\d)(.+)\)',list_c[n])
						b_mext = re.match('nn\('+list_third[0]+'(.+)\)',list_c[n])
						if a_next:
							p = re.compile(r'\(')
							list_first=p.split(a_next.string)
							list_second=list_first[1].split(' ')
							list_third = list_second[1].split(')')
							list_forth = list_third[0].split('-')
							if len(list_forth)==2:
								list_res.append(list_forth[0])
							elif len(list_forth)>2:
								stringa = ''
								for xx in range(0,len(list_forth)-1):
									stringa = stringa + list_forth[xx]
									if xx != (len(list_forth)-2):
										stringa = stringa + '-'
								list_res.append(stringa)
						elif b_mext:
							p = re.compile(r'\(')
							list_first=p.split(b_mext.string)
							list_second=list_first[1].split(' ')
							list_third = list_second[1].split(')')
							list_forth = list_third[0].split('-')
							if len(list_forth)==2:
								list_res.append(list_forth[0])
							elif len(list_forth)>2:
								stringa = ''
								for xx in range(0,len(list_forth)-1):
									stringa = stringa + list_forth[xx]
									if xx != (len(list_forth)-2):
										stringa = stringa + '-'
								list_res.append(stringa)

					for n in range(i+1,len(list_c)-1):
						a_next = re.match('poss\('+list_third[0]+'-(\d)(.+)\)',list_c[n])
						b_mext = re.match('nn\('+list_third[0]+'(.+)\)',list_c[n])
						if a_next:
							p = re.compile(r'\(')
							list_first=p.split(a_next.string)
							list_second=list_first[1].split(' ')
							list_third = list_second[1].split(')')
							list_forth = list_third[0].split('-')
							if len(list_forth)==2:
								list_res.append(list_forth[0])
							elif len(list_forth)>2:
								stringa = ''
								for xx in range(0,len(list_forth)-1):
									stringa = stringa + list_forth[xx]
									if xx != (len(list_forth)-2):
										stringa = stringa + '-'
								list_res.append(stringa)
						elif b_mext:
							p = re.compile(r'\(')
							list_first=p.split(a_next.string)
							list_second=list_first[1].split(' ')
							list_third = list_second[1].split(')')
							list_forth = list_third[0].split('-')
							if len(list_forth)==2:
								list_res.append(list_forth[0])
							elif len(list_forth)>2:
								stringa = ''
								for xx in range(0,len(list_forth)-1):
									stringa = stringa + list_forth[xx]
									if xx != (len(list_forth)-2):
										stringa = stringa + '-'
								list_res.append(stringa)
					if len(list_res)==2:
						break

			if temp_3:
				p = re.compile(r'\(')
				list_first=p.split(temp_3.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa=''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa+'-'
					list_res.append(stringa)	


			if temp_4:
				p = re.compile(r'\(')
				list_first=p.split(temp_4.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa=''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa+'-'
					list_res.append(stringa)
			if temp_5:
				p = re.compile(r'\(')
				list_first=p.split(temp_5.string)
				list_second=list_first[1].split(' ')
				list_third = list_second[1].split(')')
				list_forth = list_third[0].split('-')
				if len(list_forth)==2:
					list_res.append(list_forth[0])
				elif len(list_forth)>2:
					stringa=''
					for xx in range(0,len(list_forth)-1):
						stringa = stringa + list_forth[xx]
						if xx != (len(list_forth)-2):
							stringa = stringa+'-'
					list_res.append(stringa)
		
	if len(list_res)!=2:
		pp_ac = re.compile(r'a\ cross\ between\ (\w+)\ and\ (\w+)')
		ss_ac = pp_ac.search(sentence)
		if ss_ac:
			list_res.append(ss_ac.group(1))
			list_res.append(ss_ac.group(2))

	if len(list_res)>2:
		for i in range(0,len(list_res)-1):
			if list_res[i].islower():
				del list_res[i];
	#elif 
	if len(list_res)==2:
		#file_res.write(list_res[0]+' '+list_res[1]+'/n')
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i]+'.'
			filenames = filenames + 'parent'
		else :
			filenames = list_temp[0]+'.parent'

		file_res = open(dir_deal+filenames,'w',1)
		print >>file_res,list_res[0]+' * '+list_res[1]
			#z=z+1
			#print z
	#elif:
		#print >> file_res,list_num[0]+' no parents manage'
#file_res.close()
