import sys,io,os


def textdeal(dir_table):
	if not os.path.exists(dir_table+'table_deal\\'):
		os.mkdir(dir_table+'table_deal\\')

	list_index = os.listdir(dir_table+'table\\')
	for i in range(0,len(list_index)):
		file_read = open(dir_table+'table\\'+list_index[i],'r',1)
		file_write = open(dir_table+'\\table_deal\\'+list_index[i],'w',1)

		list_read = file_read.readlines()
		for ii in range(0,len(list_read)):
			list_lines = list_read[ii].split('\n')
			list_split = list_lines[0].split(' ')
			for iii in range(0,len(list_split)):
				llx = list_split[iii]
				if llx == '':
					continue;
				if list_split[iii] == '.':
					file_write.write('.\n')
				elif llx[-1] == '.' and len(llx)>2 and llx != 'cv.' and llx != 'ssp.' and llx != 'No.':
					file_write.write(list_split[iii]+'\n')
				elif (len(llx)==2 and llx.isupper()) or llx == 'ssp.' or llx == 'cv.' or llx == 'No.':
					file_write.write(list_split[iii])
				else :
					file_write.write(list_split[iii]+' ')

