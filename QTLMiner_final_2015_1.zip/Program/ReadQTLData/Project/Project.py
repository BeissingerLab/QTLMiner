import sys,os,io
from Get_parent import *
from Gottrait import *
from Deal_traitlist import *
try:
	from textdeal import *
except ImportError,e:
	raise


addr_now = sys.path[0]+'\\'
#print addr_now
addr = sys.argv[1]+'\\'
addr_parent = addr + 'Complement\\'
addr_trait = addr + 'Complement\\'
addr_table = addr

textdeal(addr_table)
deal_traitlist()

list_index = os.listdir(addr+'table_deal\\')
for num in range(0,len(list_index)):
	file_open = open(addr+'\\table_deal\\'+list_index[num],'r',1)
	list_sentence = file_open.readlines()
	for sentence in list_sentence:
		file_temp = open(addr+'temp','w',1)
		file_temp.write(sentence)
		file_temp.close()
		# Windows
		#print addr_now+'stanford-parser\\11.bat '+addr+'temp '+addr+'parser'
		os.system(addr_now+'stanford-parser\\11.bat '+addr+'temp '+addr+'parser')
		#Linux
		#os.system('bash '+addr+'stanford-parser\\lexparser.sh temp.txt>parser.result')
		if not parser_trait(addr_trait,sentence,list_index[num],addr):
			compare(sentence,addr_trait,list_index[num])
		listofp = definition()
		if not rule_find(sentence,addr_parent,list_index[num]):
			parser_find(listofp[0],listofp[1],listofp[2],listofp[3],listofp[4],addr_parent,list_index[num],list_index[num],addr)
