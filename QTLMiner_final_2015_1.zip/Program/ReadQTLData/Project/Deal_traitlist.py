import sys,io,os
import re

def deal_traitlist():
#	addr = os.getcwd()
	addr = sys.path[0]
	print addr
	addr_r = addr + '\\trait_list.txt'
	file_r = open(addr_r,'r',1)
	list_temp = file_r.readlines()
	file_w = open(addr+'\\trait.txt','w',1)
	for xx in range(0,len(list_temp)):
		list_sentence = list_temp[xx].split('\r\n')
		#print list_sentence
		word_list = list_sentence[0].split(' ')
		list_temp[xx] = ''
		for word in word_list:
			list_temp[xx] = list_temp[xx] + word + '\\ '
	#print list_temp[xx]+' ',xx
		list_temp[xx] = re.sub(r'\(','\\(',list_temp[xx])
		list_temp[xx] = re.sub(r'\)','\\)',list_temp[xx])
		#print list_temp[xx],"num:",num
	for lists in list_temp:
		print >> file_w,lists
	file_r.close()
	file_w.close()
