import sys,io,os
import re
import string

def get_split_get(str):
	list_temp = str.split(' ')
	list_temp = list_temp[1].split('-')
	if len(list_temp)>2:
		for xx in range(1,len(list_temp)-1):
			list_temp[0] = list_temp[0]+'-'+list_temp[xx]
	return list_temp[0]

def get_describe(lines,key_word):
	patter_des = re.compile(r'(nn|amod|num|det|vmod)\('+key_word+'.+\)')
	ax = patter_des.match(lines)
	if ax:
		return get_split_get(ax.string)
	else:
		return '-1'

def del_signal(string):
	list_temp = string.split('\\')
	string_return = ''
	for x in list_temp:
		string_return = string_return + x
	return string_return


#addr_now = sys.argv[1]
#addr_r = addr_now+'/table_deal/'
#addr_w = addr_now+'/table_trait/'
#lists = os.listdir(addr_r)
#addr_desktop = '/home/biolo/Desktop/'
#file_trait = open(addr_now+'trait_deal.txt','r',1)
#list_trait = file_trait.readlines()
def parser_trait(addr_trait,list_line,filename,addr):
	filenames = ''
	patter1 = re.compile(r'prep_with\(associated.+\)')
	patter2 = re.compile(r'prep_for\((QTL|QTLs).+\)')
#	list_word = list_line.split(' ')
	
#for list_r in lists:
#	file_r = open(addr_r+list_r,'r',1)
#	list_readonefile = file_r.readlines()
#	for list_sentence in list_readonefile:
	list_res = []
	list_res2 = []
#		file_writetemp = open('/home/biolo/Desktop/temp.txt','w',1)
#		file_writetemp.write(list_sentence)
#		file_writetemp.close()
#		os.system('bash /home/biolo/Desktop/stanford-parser-full-2014-01-04/lexparser.sh /home/biolo/Desktop/temp.txt > /home/biolo/Desktop/123')
	file_parser = open(addr+'parser','r',1)
	list_parsers = file_parser.readlines()
	for list_line in list_parsers:
		ax = patter1.match(list_line)
		bx = patter2.match(list_line)
		if ax:
			key_word = get_split_get(ax.string)
			#list_res.append(ax.group(1))
			list_res.append(key_word)
			patter_des = re.compile(r'(nn|amod|num|det|vmod)\('+key_word+'.+\)')
			for lines in list_parsers:
				ax_des = patter_des.match(lines)
				if ax_des:
					list_res.append(get_split_get(ax_des.string))
			patter_1 = re.compile(r'prep_(for|of|with|to)\('+key_word+'.+\)')
			for line in list_parsers:
				ax_1 = patter_1.match(line)
				if ax_1:
					print 'YES!!!!!!'
#					list_res2.append(ax_1.group(1))
					key_word_1 = get_split_get(ax_1.string)
					list_res2.append(key_word_1)
					for lines in list_parsers:
						list_res2.append(get_describe(lines,key_word_1))
					list_res2.append(ax_1.group(1))

		elif bx and len(list_res)==0:
			list_res.append('for')
			list_res.append(bx.group(1))
			key_word = get_split_get(bx.string)
			list_res2.append(key_word)
			for lines in list_parsers:
				list_res2.append(get_describe(lines,key_word))
	

	if len(list_res)>0 and list_res[0] == 'resistance':
		a_patter = re.compile(r'prep_to\(associated.+\)')
		b_patter = re.compile(r'aux(.+,\ to-9)')
		for list_lines in list_parsers:
			axx = a_patter.match(list_lines)
			bxx = b_patter.match(list_lines)
			if axx:
				key_word = ''
				key_word = get_split_get(axx.string)
				list_res2.append(key_word)
				for lines in list_parsers:
					list_res2.append(get_describe(lines,key_word))
				list_res2.append('to')

	if len(list_res)>0:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i] + '.'
			filenames = filenames + 'trait'
		else :
			filenames = list_temp[0]+'.trait'
		file_w = open(addr_trait+filenames,'a',1)
		for xx in range(len(list_res)-1,-1,-1):
			if list_res[xx]!='-1':
				print >> file_w,list_res[xx]+' ',
		if len(list_res2)!=0:
			for xx in range(len(list_res2)-1,-1,-1):
				if list_res2[xx] != '-1':
					print >>file_w,list_res2[xx]+' ',
		file_w.write('\n')
		file_w.close()
		return 1

def compare(sentence,addr_parent,filename):
	filenames = ''
	list_res = []
	file_trait = open(sys.path[0]+'\\trait.txt','r',1)
	list_trait = file_trait.readlines()
	for trait in list_trait:
		trait_temp = trait.split('\n')
		check_signal = re.match(r'.+\ '+trait_temp[0]+'(.+)?',sentence,re.IGNORECASE)
		if check_signal:
			list_res.append(del_signal(trait_temp[0]))
				#file_w = open(addr_w+list_r,'w',1)
				#print >> file_w,del_signal(check_signal.string),
				#continue
	if len(list_res) > 0:
		list_temp = filename.split('.')
		if len(list_temp) > 2:
			for i in range(0,len(list_temp)-1):
				filenames = filenames + list_temp[i] + '.'
			filenames = filenames + 'trait'
		else :
			filenames = list_temp[0]+'.trait'
		file_w = open(addr_parent+filenames,'a',1)
		for xx in range(0,len(list_res)-1):
			print >> file_w,list_res[xx]+' * ',
		print >> file_w,list_res[len(list_res)-1]
			#continue
#			file_w.close()
