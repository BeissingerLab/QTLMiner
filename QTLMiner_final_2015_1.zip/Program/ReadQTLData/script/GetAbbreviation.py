import sys,os
import sys
reload(sys)
sys.setdefaultencoding('utf8')

logfile2 = '/home/jackie/Vacation/0618Information/outTxtFile/PMID_19959597.txt'
args=sys.argv
logfile2=args[1]
PATH = args[1]+'/text/'
PATH2 = args[1]+'/tabletext/'
PATH3 = args[1]+'/Abbreviation/'
filelist = os.listdir(PATH)
for filename in filelist :
	input = open(PATH+filename,"r")
#	input = open(logfile2,"r")
	#f=open('out.txt','a')
	f=open(PATH3+filename,'w')
       	line=input.readline()
	logfile2 += "\n"
	#f.write(logfile2)
	d={}
	#print >> sys.stderr,"start!!!!!!!!!!!!!!",PATH+filename
        while line:  
		lines=line[::-1]
		List = lines.split()
		i=0
		flage2 = 0 
		abb2 = ""
		Word2 = ""
		#print >> sys.stderr,line
		for word in List:
			s=""
			Len=len(word)
			if abb2.strip():
				abb2 += " "
			if (Len >= 3):
				flage = 0
				Word = ""
				abb = ""
				for letter in word:
					if letter == "(":  
						flage = 0
						flage2 = 0
						if Word.strip()=='':
							Word = Word2
							abb = abb2
						abb2 = ""
						Word2 = ""
					if flage:
						abb += letter
						if letter.isalpha():
							Word += letter
					if flage2:
						if letter.isalpha():
							Word2 += letter
						abb2 += letter
					if letter == ")":
						flage = 1
						flage2 = 1
					if (letter == ",") or (letter == ";"):
						abb2 = ""
						Word2 = ""
				if flage :
					Word += "1" 
				#print >> sys.stderr,"Word::",Word,"Word2::",Word2,"abb::",abb,"abb2::",abb2,"word::",word
				if (len(Word)==1) and (Word.isalpha()):#Judge only one letter of the abbreviation
					if i < (len(List)-1):
						Len=len(List[i+1])
						if Word[0].lower()==List[i+1][Len-1].lower():
							s += List[i+1]
							s = s[::-1]
							abb = abb[::-1]
					if(s!=""):
						#if d.has_key(abb)==False:
						d[abb] = s
				elif Word.isalpha():#Judge uppercase abbreviation
					Wlen=len(Word)
					Len=len(List)
					o=0#Traversing an abbreviated location
					l=1#Traversal of the position of the word
					if((i+l) < Len):
						lwen=len(List[i+l])
					for m in List:
						if ((i+l) <= Len) and (o < Wlen):
							if((i+l)== Len):
								l=l-1
							if (len(List[i+l])==1) and (List[i+l][0]==")"):
								s=""
								break
							if (len(List[i+l])!=1) and (List[i+l][1]==")"):
								s=""
								break
							p=0#Letter word position traverse
							for n in List[i+l]:
								##print >> sys.stderr,"i",i,"o",o,"l",l,"p",p,"lwen",lwen,"Wlen",Wlen
								if (o < Wlen) and (p<=(lwen-1)):
									if Word[o].lower()==List[i+l][p].lower():
										if p==(lwen-1):
											s += List[i+l]
											s += " "
											#print >> sys.stderr,"Word",Word
											#print >> sys.stderr,"i",i,"o",o,"l",l,"p",p,"Len",Len,"Word[o]",Word[o],"List[i+l]",List[i+l],"ssssssssssss",s		
											o=o+1
											p=-1
											l=l+1
											if((i+l) == Len):
												l=l+1
												break
											else:
												lwen=len(List[i+l])
										else:
											if o < (Wlen-1):
												o=o+1
									elif (Word[o].lower()!=List[i+l][p].lower()) and p==(lwen-1):
											s += List[i+l]
											s += " "
											#print >> sys.stderr,"Word",Word
											#print >> sys.stderr,"i",i,"o",o,"l",l,"p",p,"Len",Len,"Word[o]",Word[o],"List[i+l]",List[i+l],"ssssssssssss",s	
											p=-1
											l=l+1
											if((i+l) == Len):
												s=""
												l=l+1
												break
											else:
												lwen=len(List[i+l])
								p=p+1
					s = s[::-1]
					s=s[1:]
					abb = abb[::-1]
					if(s!=""):
						if d.has_key(abb)==False:
							d[abb] = s	
			i=i+1
        	line=input.readline()
	input.close
	Sstr1='.'
	Sstr3=')'
	Sstr4='('
	Sstr2=','
	Sstr5=';'
	for word in d:
		#if (d[word].find(Sstr1) < 0) and (d[word].find(Sstr2) < 0):
			#print >> sys.stderr,d[word]
		if (d[word].find(Sstr1) < 0) and (d[word].find(Sstr3) < 0)and(d[word].find(Sstr4) < 0)and(d[word].find(Sstr2) < 0) and (d[word].find(Sstr5) < 0) and (word != "i.e.") and (word != "e.g.") and (len(word) < len(d[word])) and (len(d[word]) < 50):
			f.write(word)
			f.write(":")
			f.write(d[word])
			f.write("\n")
	#f.write("\n")
	f.close

filelist = os.listdir(PATH2)

for filename in filelist :
	input = open(PATH2+filename,"r")
	f=open(PATH3+filename,'a')
       	line=input.readline()
	while line:
		List = line.split()
		Abb = ""
		name = ""
		for word in List:
			Len = len(word)
			if word[0]=="(" and word[Len-1]== ")":
				Abb = word[1:Len-1:]
				if ((Abb >= u'\u0041' and Abb<=u'\u005a') or (Abb >= u'\u0061'and Abb<=u'\u007a')) and (len(Abb) > 1) and (name.strip()!=""):
					f.write(Abb+":"+name[0:-1:]+"\n")
				name = ""
			else:
				name += word+" "
		line=input.readline()
	f.write("\n")
	f.close

