#2014-10-11
#lidongye
$argc = @ARGV;
printf("$argc\n");
if($argc == 1)
{
	$PATH = $ARGV[0];
	$htmpath = $PATH."//htm//";
	$refpath = $PATH . "//Complement//";
}
elsif($argc == 2)
{
	$htmpath = $ARGV[0]."//";
	$refpath = $ARGV[1]."//";
}
else
{
	die "ARGV error!";
}
opendir(HTM,$htmpath);
#foreach $file(grep(!/^\.\.?$/,readdir HTM))
foreach $file(grep(/\.htm$/,readdir HTM))
{
	print"$file \n";
	$reffile = $file;
	$reffile =~ s/.htm/.ref/;
	open(fin,$htmpath.$file);
	
	while($line = <fin>)
	{
		if($line =~ /<DIV/)
		{
		
			$i=0;
			$ref1="";
			$ref2="";
			$tmpref="";
			while($i<3)
			{
				$line=<fin>;
				if($line =~ /(<P|<TD)/)
				{
					$line =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
					$line =~ s/�./-/g;
					$tmp = () = $line =~ /\S+/g;
					next if $tmp > 20;
					#print "text $line\n���е����� $tmp \n";
					if ($line =~ /doi/i)
					{
						
						if ($i > 0 && $ref1 eq "")
						{
							$ref1 = $tmpref;
							#print "dioref1 $ref1 \n"
						}
						$ref2 = $line;
						printf "$ref2 \n";
						last;
					}
					elsif($line =~ /.+\d{4}.*/ && $ref1 eq "")
					{
						$ref1 = $line;
						#print "ref1 $line \n";
					}
					else
					{
						$tmpref = $line;
					}
					$i++;
				}
			}
			if ($ref1 =~ /.+/ || $ref2 =~ /.+/)
			{
				open(fout,">$refpath$reffile");
				print fout $ref1." ".$ref2 ;
				close(fout);
			}
			else
			{
				while($line = <fin>)
				{
					#print ("$line\n");
					last if($line =~ /<DIV\ id="id_[^1]/);
					if($line =~ /(<P|<TD)/)
					{
						$line =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
						$line =~ s/�./-/g;
						$tmp = () = $line =~ /\S+/g;
						next if $tmp > 20;
						#print "text $line\n���е����� $tmp \n";
						if ($line =~ /doi/i)
						{
							open(fout,">$refpath$reffile");
							print fout $line ;
							close(fout);
							last;
						}
					}
				}
			}
			last;
		}
	}
	close(fin);

}