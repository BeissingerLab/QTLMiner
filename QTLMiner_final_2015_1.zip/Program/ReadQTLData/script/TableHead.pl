$argc = @ARGV;
#printf($argc);
if($argc == 1)
{
	$PATH = $ARGV[0];
	$htmpath = $PATH."\\htm\\";
	$refpath = $PATH . "\\table\\";
}
elsif($argc == 2)
{
	$htmpath = $ARGV[0]."\\";
	$refpath = $ARGV[1]."\\";
}
else
{
	die "ARGV error!";
}
opendir(HTM,$htmpath);
foreach $file(grep(!/^\.\.?$/,readdir HTM))
{
	print"$htmpath$file\n";
	$tablefile = $file;
	$tablefile =~ s/.htm//;
	open(FILE,$htmpath.$file);
	$count=0;
	@text = <FILE>;
	for($i=0; $i <= $#text; $i++)
	{
		#print "$i \n";
		if ($text[$i] =~ /<TABLE/)
		{
			$string = "";
			$count++;
#			print"$count\n";		
			$j = $i-1;
			$j = 0 if $j<0 ;
			while($j>=$i-12 && $j>=0)
			{
				if($text[$j] =~ /\/TABLE>/)
				{
					last;
				}
				elsif($text[$j] =~ />Table I|>T.{0,30}AB.{0,20}LE.{0,20}\d+|>T 1:|>.{10,16}Table.{0,5}\d+|>T.{10,20}A.{1,3}BL.{1,3}E.{5,10}\d+/i)	
				{				
					$text[$j] =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
					$tmp = () = $text[$j] =~ /\s+/g;
					if($tmp <90)
					{
						$string = $string.$text[$j];
					}
					$q = $j +1;
					$q = 0 if $q<0;
					while ($q <= $#text)
					{				
						if($text[$q] =~ /\/TABLE>|\&nbsp/)
						{
							last;
						}				
						$text[$q] =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
						$tmp = () = $text[$q] =~ /\s+/g;
						if($tmp > 4 && $tmp <30)
						{
							$string0 = " $text[$q]";
							$string = $string.$string0;
						}
						$q++;
						if($q > $text[$j]+5)
						{
							last;
						}
					}
				}			
				$j--;
			}
			$j = $i+1;
			while($j <= $#text)
			{
				
				if($text[$j] =~ /\/TABLE>/)
				{
					last;
				}
				elsif($text[$j] =~ /\d+Table|>T.{0,30}AB.{0,20}LE.{0,20}\d+|>.{0,16}Table.{0,5}\d+|>T.{10,20}A.{1,3}BL.{1,3}E.{5,10}\d+/i)
				{
					$text[$j] =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
					$tmp = () = $text[$j] =~ /\s+/g;
					if($tmp <90)
					{
						$string = $string.$text[$j];
					}
					$q = $j +1;
					$q = 0 if $q<0;
					while ($q <= $#text)
					{				
						if($text[$q] =~ /\/TABLE>|\&nbsp/)
						{
							last;
						}				
						$text[$q] =~ s/<([^<>]|(?0))*>|[\n\t\r]//g;
						$tmp = () = $text[$q] =~ /\s+/g;
						if($tmp > 4 && $tmp <30)
						{	
							$string0 = " $text[$q]";
							$string = $string.$string0;	
						}
						$q++;
						if($q > $text[$j]+5)
						{
							last;
						}
					}
				}
				$j++;
			}
			$i = $j;
			if($string ne "")			
			{	
				open(PUT,">$refpath$tablefile"."table$count.txt");
#				print "$refpath$tablefile"."table$count.txt\n";	
				print PUT "$string";
				close(PUT);
			}
		}

	}
	close(FILE);
}
