$argc = @ARGV;
printf($argc);
if($argc == 1)
{
	$PATH = $ARGV[0];
	$htmpath = $PATH."//htm//";
	$textpath = $PATH . "//text//";
	$tabletextpath =  $PATH . "//tabletext//";
	$rilpath = $PATH . "//Complement//";
}
elsif($argc == 4)
{
	$htmpath = $ARGV[0]."//";
	$textpath = $ARGV[1]."//";
	$tabletextpath = $ARGV[2]."//";
	$rilpath = $ARGV[3]."//";
}
else
{
	die "ARGV error!";
}

opendir(HTM,$htmpath);
foreach $file(grep(/\.htm$/,readdir HTM))
{
	$textfile = $file;
	$rilfile = $file;
	$rilfile =~ s/.htm/.ril/;
	$textfile =~ s/.htm/.txt/;
	open(fin,$htmpath.$file);
	open(fout1,">$textpath$textfile");
	open(fout2,">$tabletextpath$textfile");
	$tmp1 = "";
	$tmp2 = "";
	while($line = <fin>)
	{
		if($line =~ /\/P>$/)
		{
			$line =~ s/<([^<>]|(?0))*>//g;
			if($line =~ /(F)\(?\ ?(\d+:\d+)/)
			{
				open(fout3,">>$rilpath$rilfile");
				$ril = $1.$2;
				print fout3 "$ril\n";
				close(fout3);
			}
			if($line =~ /^\(/)
			{
				$tmp1 =~ s/(\n)$/./;
				$tmp1 = $tmp1.$line;
			}
			else
			{
				print fout1 "$tmp1";
				$tmp1 = $line;
			}
		}
		elsif($line =~ /\/TD>$/)
		{
			$line =~ s/<([^<>]|(?0))*>//g;
			print fout2 "$line";
			#print "$line \n";
		}
	}
	print fout1 "$tmp1";
	print"$file \n";
}