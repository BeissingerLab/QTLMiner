<?php  $keyword=$_GET["key"]; ?>
<HTML>
<HEAD>
<TITLE>QTLMiner</TITLE>
</HEAD>
<FRAMESET rows="*,45">
	<FRAME SRC="./page/index.php<?php if($keyword != "") echo "/?key=$keyword"; ?>" name="showdata" scrolling="auto" noresize frameborder="0" >
	<FRAME SRC="./page/Bottom.php" NAME="Bottom" scrolling="no" noresize frameborder="0" >
<!-- <frame src="UntitledFrame-4"> -->
</FRAMESET>
<noframes>
<p>
The website homepage can be viewed only with a browser that is capable of frames.
</noframes>
</HTML>
