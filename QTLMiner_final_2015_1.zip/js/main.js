function putfilename(){
	document.uploadForm.file1.value=$("#uploadFile")[0].value;
	document.uploadForm.file1.style.color='#555555';
	document.uploadForm.file0.value=$("#uploadFile")[0].value;
	document.uploadForm.file0.style.color='#555555';
}

function uploadfile(){
	$("#FileForm");
	changeCFdiv();
	$("#FileForm").submit();
}
function Display_set(id, state)
{
	document.getElementById(id).style.display = state;
}
function Html_set(id, string)
{
	document.getElementById(id).innerHTML = string;
	
}
function changeCFdiv()
{
	//document.getElementById("div0").style.paddingTop = "20px";
	Display_set("div0", "none");
	Display_set("div1", "block");
}